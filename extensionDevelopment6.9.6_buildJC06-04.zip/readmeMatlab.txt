==============================
Intro To MIM MATLAB Extensions
==============================

MIM supports integration with MATLAB code via the use of MATLAB extensions.  This integration is accomplished by MIM launching
MATLAB, sending data to the MATLAB process (such as images, contours, and alignment information), and running a custom MATLAB
program (this program is the extension itself).  Once the program has finished, MIM reads back and displays any new images/ROIs
that were produced by the extension.

Sample MATLAB extensions can be found within the 'sampleWorkspace' directory in the directories with a 'matlab' prefix.
These samples demonstrate most of the basic operations that can be performed using MATLAB extensions such as sending/receiving
images and ROIS to/from MATLAB as well as how to properly convert coordinates between different images.

See the MIM Extensions MATLAB Quick Start.pdf file for more information about how to start building MATLAB extensions.


========================================================================
Configuring Extension Metadata (Name, Description, Inputs, Outputs, etc)
========================================================================

All extension metadata is configured via the 'info.properties' file in the 'resources' directory of the extension's
project folder. 

All properties are set using this syntax (see sample extensions for examples):
[PROPERTY NAME]=[PROPERTY VALUE] 

The following properties can be configured via the info.properties file:

	NAME - The extension's name
	AUTHOR - The extension's author
	(Note that the combination of NAME + AUTHOR is used as the extension's "Unique Identifier", so two different extensions
		cannot have the same name/author pair.)

	CATEGORY - The extension's category (For display purposes only)
	DESC - The extension's description (For display purposes only)
	COMPANY - The company associated with this extension (For display purposes only)
	WEBSITE - The website associated with this extension (For display purposes only)
	VERSION - The version number of this extension (For display purposes only)
	ICON - The name of an image file located in the extension's src directory. This image will be used as the extension's icon when MIM
		is configured to display the extension in the quick tool bar.
	ENTRY_FUNCTION - The name of the .m file (without the .m extension) that will be executed when this extension is launched. The file must 
		be located in the 'src' directory of the extension's project folder.

 
It is also possible to explicitly specify the inputs and outputs of the extension via the info.properties file. This
is not required, but it enables the extension's outputs to be used within workflows and makes the extension easier to
launch from within MIM since the user will not be required to manually enter variable names.

Inputs can be specified using this syntax:
INPUT_[INPUT NAME]=[INPUT TYPE]

Outputs can be specified using this syntax:
OUTPUT_[OUTPUT NAME]=[OUTPUT TYPE]

The INPUT_TYPE/OUTPUT_TYPE params specify the type of the input/output (ie, whether it's a number, contour, or image volumes) and
must be selected from the following types (all types within each group are effectively equivalent):

NUM
NUMBER
DOUBLE
FLOAT

INT
INTEGER
SHORT
LONG

BOOL
BOOLEAN

STRING
TEXT
MESSAGE

SERIES
VOLUME

CONTOUR
ROI
RTST
RTSTRUCT

DOSE
RTDOSE
ISODOSE
