package sample.control;

import java.io.File;
import java.util.List;

import javax.swing.JFileChooser;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.series.XMimImage;

import sample.contouring.ContourMinMaxFinder;
import sample.contouring.ContourToCsv;

public class Launcher {

	private static final String mmDesc = "Finds the max voxel in the provided contour and creates a marker contour for it on the provided image.";
	
	@XMimEntryPoint(name="Max Finder", author="Anonymous", description=mmDesc, category="Contouring")
	public Object[] runOnSession(XMimSession session, XMimImage destinationImage, List<XMimContour> targetContours) {
		
		for (XMimContour targetContour : targetContours) {
			ContourMinMaxFinder finder = new ContourMinMaxFinder(session, targetContour);
			
			XMimNoxelPointF maxLoc = finder.getMaxLocation();
			
			XMimLinkController linker = session.getLinker();
			
			XMimContour maxCon = destinationImage.createNewContour("MAX: "+finder.getMax()+" "+destinationImage.getInfo().getUnits());
			
			XMimNoxelPointF destPos = linker.toRawNoxel(maxLoc, maxCon.getSpace());
			maxCon.getData().setValue(destPos.toRawDataLocation(), true);
		}
	
		return null;
	}
	
	private static final String csvDesc = "Outputs a CSV file that contains a list of all of the scaled values of the"+
			" multiplied voxels contained within the selected contour.";
	
	@XMimEntryPoint(name="Contour to CSV", author="MIM", category="Utilities", description=csvDesc)
	public static Object[] runOnContour(XMimSession sess, XMimContour con) {
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogType(JFileChooser.SAVE_DIALOG);
		jfc.setSelectedFile(new File("contourData.csv"));
		jfc.showSaveDialog(null);
		
		File file = jfc.getSelectedFile();
		
		if (file == null) {
			return null;
		}
		
		System.out.println("csv path "+file.getAbsolutePath());
		
 		ContourToCsv csv = new ContourToCsv(sess);
		csv.writeCsv(con, null, file);
		
		return new Object[0];
	}
}
