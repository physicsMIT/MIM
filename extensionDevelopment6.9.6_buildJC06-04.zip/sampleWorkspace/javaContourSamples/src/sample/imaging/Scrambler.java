package sample.imaging;

import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimMutableImage;

public class Scrambler {

	public static void scramblerRecurse(XMimMutableImage img, int dim, XMimNoxelPointI nox) {
		int[] dims = img.getRawData().getDims();
		for (int i=0; i<dims[dim]; i++) {
			nox.setCoord(dim, i);
			if (dim == dims.length-1) {
				img.getRawData().setValue(nox, (short)(Math.random()*5000));
			} else {
				scramblerRecurse(img, dim+1, nox);
			}
		}
	}
	
}
