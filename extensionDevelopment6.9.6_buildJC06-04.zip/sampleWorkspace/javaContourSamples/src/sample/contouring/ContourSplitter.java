package sample.contouring;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimImageSpace;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.stats.XMimContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumericContourStat;

public class ContourSplitter {
	
	private static final String desc = "Splits a contour by slice.";

	
	@XMimEntryPoint(name="Contour Splitter", author="Anonymous", 
			description=desc, category="Contouring")
	public static Object[] runOnContour(XMimSession session, XMimContour contour){
		

		XMimLinkController link = session.getLinker(); 
		XMimImageSpace volSpace = contour.getMimImage().getSpace();

    	XMimNoxelPointI drawCursor = contour.getMimImage().createNoxelPointI();
    	
    	String contourName = contour.getInfo().getName();
		XMimNoxelPointI cursor = contour.getSpace().createNoxelPoint().toRawDataLocation();

    	List<XMimContour> contourList = new ArrayList();
		int[] conDims = contour.getData().getDims();

		Map<Integer, XMimContour> contourMap = new HashMap();

		Iterable<? extends XMimMutableRLEIterator> rle = contour.getData().getRleIterable();

		drawCursor.setCoord(2, 0);

		for (XMimMutableRLEIterator it : rle) {
			int rangeStart = -1;
			int rangeEnd = -1;

			while (it.hasNext()) {
				it.advanceToNextNewValue(cursor);

				if (it.getBoolean()) {
					rangeStart = cursor.getCoord(0);
					if (it.hasNext()) {
						continue;
					} else {
						rangeEnd = conDims[0];
					}
				} else {
					rangeEnd = cursor.getCoord(0);
					if (rangeStart == -1) {
						continue;
					}
				}

				drawCursor.setCoord(1, cursor.getCoord(1));
				drawCursor.setCoord(2, cursor.getCoord(2));

				for(int x = rangeStart; x < rangeEnd; x++){

					int z = cursor.getCoord(2);
					
					

					XMimContour currentContour = contourMap.get(z);
					if(currentContour == null){
						
						XMimNoxelPointF voxCenter = cursor.toVoxelCenter();
						XMimPointF result = link.convertPoint(voxCenter, volSpace, session.getPointFactory().getDicomCoordSystem());
						
						
						currentContour = contour.getMimImage().createNewContour(contourName + " " + result.getCoord(2));
						contourMap.put(z, currentContour);
					}

					drawCursor.setCoord(0, x);
					currentContour.getData().setValue(drawCursor, true);

				}
			}
		}
		
		contour.redrawCompletely();
		return null;

	}
	
	private static float[] getContourBoundingBox(XMimSession session, XMimContour contour){
		
		XMimLinkController link = session.getLinker(); 
		XMimImageSpace volSpace = contour.getMimImage().getSpace();

    	    	
    	float xMin = Float.POSITIVE_INFINITY;
    	float xMax = Float.NEGATIVE_INFINITY;
    	
    	float yMin = Float.POSITIVE_INFINITY;
    	float yMax = Float.NEGATIVE_INFINITY;
    
    	float zMin = Float.POSITIVE_INFINITY;
    	float zMax = Float.NEGATIVE_INFINITY;
    	
		int[] conDims = contour.getData().getDims();
		XMimNoxelPointI cursor = contour.getSpace().createNoxelPoint().toRawDataLocation();
    	
		Iterable<? extends XMimMutableRLEIterator> rle = contour.getData().getRleIterable();
		for (XMimMutableRLEIterator it : rle) {
			int rangeStart = -1;
			int rangeEnd = -1;
			
			while (it.hasNext()) {
				it.advanceToNextNewValue(cursor);
				
				if (it.getBoolean()) {
					rangeStart = cursor.getCoord(0);
					if (it.hasNext()) {
						continue;
					} else {
						rangeEnd = conDims[0];
					}
				} else {
					rangeEnd = cursor.getCoord(0);
					if (rangeStart == -1) {
						continue;
					}
				}
				
				for(int x : new int[]{rangeStart, rangeEnd}){
					cursor.setCoord(0, x);
					XMimNoxelPointF voxCenter = cursor.toVoxelCenter();
					XMimPointF result = link.convertPoint(voxCenter, volSpace, session.getPointFactory().getDicomCoordSystem());
					
					float xc = result.getCoord(0);
					float yc = result.getCoord(1);
					float zc = result.getCoord(2);

					xMin = Math.min(xMin, xc);
					xMax = Math.max(xMax, xc);

					yMin = Math.min(yMin, yc);
					yMax = Math.max(yMax, yc);
					
					zMin = Math.min(zMin, zc);
					zMax = Math.max(zMax, zc);

				}
				
			}
		
		}
		
		return new float[]{xMin, xMax, yMin, yMax, zMin, zMax}; 
	}
	
	private static void actuallyAPLength(final XMimSession sess) {
		//register the statistic on the session so that all contours will receive it
		sess.registerNewStat(new XMimNumericContourStat() {
			@Override
			public String getStatName() {
				return "AP Length";
			}
			@Override
			public XMimContourStatId getStatId() {
				//other extensions could refer to our statistic using this ID and namespace
				return new XMimContourStatId("ap_length", "MIMEX");
			}
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				//MIM will compute these stats before computing ours
				Set<XMimContourStatId> reqs = new HashSet<XMimContourStatId>();
				return reqs;
			}
			@Override
			public String getAbbreviatedName() {
				//there is never enough space...
				return "AP Len";
			}			
			@Override
			public Number computeResult(XMimContourStatContext context) {
				
				float[] bb = getContourBoundingBox(sess, context.getContour());
				
				return bb[3] - bb[2];
			}
		});
	}
	
	private static void actuallyLateralLength(final XMimSession sess) {
		//register the statistic on the session so that all contours will receive it
		sess.registerNewStat(new XMimNumericContourStat() {
			@Override
			public String getStatName() {
				return "Lat Length";
			}
			@Override
			public XMimContourStatId getStatId() {
				//other extensions could refer to our statistic using this ID and namespace
				return new XMimContourStatId("lat_length", "MIMEX");
			}
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				//MIM will compute these stats before computing ours
				Set<XMimContourStatId> reqs = new HashSet<XMimContourStatId>();
				return reqs;
			}
			@Override
			public String getAbbreviatedName() {
				//there is never enough space...
				return "Lat Len";
			}			
			@Override
			public Number computeResult(XMimContourStatContext context) {
				
				float[] bb = getContourBoundingBox(sess, context.getContour());
				
				return bb[1] - bb[0];
			}
		});
	}
	
	private static void actuallyLongLength(final XMimSession sess) {
		//register the statistic on the session so that all contours will receive it
		sess.registerNewStat(new XMimNumericContourStat() {
			@Override
			public String getStatName() {
				return "Long Length";
			}
			@Override
			public XMimContourStatId getStatId() {
				//other extensions could refer to our statistic using this ID and namespace
				return new XMimContourStatId("long_length", "MIMEX");
			}
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				//MIM will compute these stats before computing ours
				Set<XMimContourStatId> reqs = new HashSet<XMimContourStatId>();
				return reqs;
			}
			@Override
			public String getAbbreviatedName() {
				//there is never enough space...
				return "Long Len";
			}			
			@Override
			public Number computeResult(XMimContourStatContext context) {
				
				float[] bb = getContourBoundingBox(sess, context.getContour());
				
				return bb[5] - bb[4];
			}
		});
	}
	
	@XMimEntryPoint(
			name="A-P dimension",
			author="MIM",
			category="Statistics",
			description="Adds a statistic that is the total length of the contour in the AP direction")
	public static Object[] registerAPStat(XMimSession sess) {
		actuallyAPLength(sess);

		//since we only want to register the stat, we can return nothing
		return new Object[0];
	}
	
	@XMimEntryPoint(
			name="Lateral dimension",
			author="MIM",
			category="Statistics",
			description="Adds a statistic that is the total length of the contour in the lateral direction")
	public static Object[] registerLatStat(XMimSession sess) {
		actuallyLateralLength(sess);

		//since we only want to register the stat, we can return nothing
		return new Object[0];
	}
	
	@XMimEntryPoint(
			name="Longitudinal dimension",
			author="MIM",
			category="Statistics",
			description="Adds a statistic that is the total length of the contour in the longitudinal direction")
	public static Object[] registerLongStat(XMimSession sess) {
		actuallyLongLength(sess);

		//since we only want to register the stat, we can return nothing
		return new Object[0];
	}
	

	
}
