package sample.contouring;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import com.google.common.collect.Lists;
import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.stats.XMimNumericContourStatBase;

public class StatDisplayer {

	JDialog myFrm;
	JPanel mainPanel;
	JPanel statsPanel;
	
	Map<StatKey, String> statMap = new HashMap<StatKey, String>();
	
	private static class StatKey implements Comparable<StatKey> {
		private XMimContour contour;
		private XMimNumericContourStatBase<?> stat;
		
		public StatKey(XMimContour contour, XMimNumericContourStatBase<?> stat) {
			this.contour = contour;
			this.stat = stat;
		}
		
		@Override
		public int compareTo(StatKey o) {
			int nameComp = contour.getInfo().getName().compareTo(o.contour.getInfo().getName());
			if (nameComp != 0) {
				return nameComp;
			} else {
				return stat.getStatName().compareTo(o.stat.getStatName());
			}
		}
		
		//hashCode and equals autogenned by Eclipse 
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((contour == null) ? 0 : contour.hashCode());
			result = prime * result + ((stat == null) ? 0 : stat.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			StatKey other = (StatKey) obj;
			if (contour == null) {
				if (other.contour != null) {
					return false;
				}
			} else if (!contour.equals(other.contour)) {
				return false;
			}
			if (stat == null) {
				if (other.stat != null) {
					return false;
				}
			} else if (!stat.equals(other.stat)) {
				return false;
			}
			return true;
		}
	}
	
	public StatDisplayer(Window parent) {
		buildGui(parent);
	}
	
	private void buildGui(Window parent) {
		myFrm = new JDialog(parent, "Extension Stat Displayer");
		JMenuBar menu = new JMenuBar();
		JMenu jm = new JMenu("File");
		JMenuItem closeItem = new JMenuItem("Close");
		
		closeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				myFrm.dispose();
			}
		});
		
		jm.add(closeItem);
		menu.add(jm);
		myFrm.setJMenuBar(menu);
		
		myFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		myFrm.setSize(new Dimension(300,200));
		
		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.setPreferredSize(new Dimension(300,200));
		
		JLabel header = new JLabel("Extension Stats");
		header.setHorizontalAlignment(JLabel.CENTER);
		header.setAlignmentX(Box.CENTER_ALIGNMENT);
		mainPanel.add(header);
		
		statsPanel = new JPanel();
		statsPanel.setAlignmentX(Box.CENTER_ALIGNMENT);
		statsPanel.setLayout(new GridBagLayout());
		rebuildRows();
		
		myFrm.add(mainPanel);
		mainPanel.add(statsPanel);
	}

	private synchronized void rebuildRows() {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		statsPanel.removeAll();
		
		List<StatKey> sortedKeys = Lists.newArrayList(statMap.keySet());
		Collections.sort(sortedKeys);
		
		XMimContour prevCon = null;
		
		for (StatKey sk : sortedKeys) {
			boolean newCon = false;
			if (prevCon == null || prevCon.equals(sk.contour)) {
				newCon = true;
				prevCon = sk.contour;
			}
			
			XMimNumericContourStatBase<?> stat = sk.stat;
			
			if (newCon) {
				JLabel conLbl = new JLabel(prevCon.getInfo().getName());
				conLbl.setHorizontalAlignment(JLabel.LEFT);
				statsPanel.add(conLbl, gbc);
				gbc.gridy++;
			}
			
			String val = statMap.get(sk);
			
			JLabel nameLbl = new JLabel(stat.getStatName()+": ");
			nameLbl.setHorizontalAlignment(JLabel.RIGHT);
			JLabel valLbl = new JLabel(val);
			valLbl.setHorizontalAlignment(JLabel.LEFT);
			
			gbc.gridx = 0;
			statsPanel.add(nameLbl, gbc);
			gbc.gridx = 1;
			statsPanel.add(valLbl, gbc);
			gbc.gridy++;
		}
		
		if (statMap.isEmpty()) {
			gbc.gridx = 0;
			gbc.gridwidth = 2;
			JLabel noneLbl = new JLabel("<No Stats Currently Computed>");
			noneLbl.setHorizontalAlignment(JLabel.CENTER);
			statsPanel.add(noneLbl, gbc);
		}
		
		statsPanel.revalidate();
		statsPanel.repaint();
	}
	
	public boolean isVisible() {
		return myFrm.isVisible();
	}
	
	public void setVisible(boolean viz) {
		myFrm.pack();
		myFrm.setVisible(viz);
	}
	
	public synchronized void updateStat(XMimNumericContourStatBase<?> stat, XMimContour con, String newVal) {
		StatKey sk = new StatKey(con, stat);
		
		String oldVal = statMap.get(sk);
		statMap.put(sk, newVal);
		
		if (oldVal == null || !oldVal.equals(newVal)) {
			rebuildRows();
		}
	}
}
