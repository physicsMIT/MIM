package sample.contouring;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimSeriesView;

public class SphereMaker {
	
	private static final String contourSphereDesc = "Draws a roughly spherical contour in the center of the image with a radius of 25 mm.";
	
	@XMimEntryPoint(name="Draw Sphere", author="MIM", category="Contouring", description=contourSphereDesc)
	public static Object[] run(XMimSession sess, XMimImage img) {
		XMimContour con = img.createNewContour("Sphere");
		
		int[] dims = img.getSpace().getDataDims();
		XMimNoxelPointF center = img.createNoxelPointF();
		for (int i=0; i<img.getSpace().getDimensionCount(); i++) {
			center.setCoord(i, dims[i]/2f);
		}
		
		center = sess.getLinker().convertPoint(center, con.getSpace(), center.getCoordSystem()).toNoxel();
		
		drawSphere(con, center, 50);
		con.redrawCompletely();
		
		return null;
	}
	
	private static final String sphereAtLocDesc = "Draws a roughly spherical contour centered on the crosshairs with a radius of 15 mm.";
	
	@XMimEntryPoint(name="Draw Sphere At Crosshairs", author="MIM", category="Contouring", description=sphereAtLocDesc)
	public static Object[] drawSphereAtCrosshairs(XMimSession sess, XMimSeriesView img) {
		XMimContour con = img.getImage().createNewContour("Sphere");
		XMimNoxelPointF crosshairPosImgSpace = img.getCrosshairLocation();
		XMimNoxelPointF crosshairPosContourSpace = sess.getLinker().convertPoint(crosshairPosImgSpace, con.getSpace(), crosshairPosImgSpace.getCoordSystem()).toNoxel();
		
		drawSphere(con, crosshairPosContourSpace, 30);
		con.redrawCompletely();
		
		return null;
	}
	
    private static void drawSphere(XMimContour contour, XMimNoxelPointF center, float diameterInMm) {
    	float[] noxSize = contour.getSpace().getNoxSize();
    	float rad = diameterInMm/2;
    	
    	int zVoxRadius = (int)Math.ceil(rad/noxSize[2]);
    	
    	XMimNoxelPointI drawCursor = contour.getMimImage().createNoxelPointI();
    	
    	float centerZ = center.getCoord(2);
    	for (short dZ = 0; dZ <= zVoxRadius; dZ++) {
			int zVoxLoc = Math.round(dZ+centerZ);
			float metricZOffset = (zVoxLoc-centerZ)*noxSize[2];
			float diffy = rad*rad - metricZOffset * metricZOffset;
			
			drawCursor.setCoord(2, zVoxLoc);
			
			if (diffy > 0) {
				float circleRadiusForThisZ = (float) (Math.sqrt(diffy));
				drawCircle(contour, center, circleRadiusForThisZ*2, drawCursor);
			}

			zVoxLoc = Math.round(-dZ+centerZ);
			metricZOffset = (zVoxLoc-centerZ)*noxSize[2];
			diffy = rad * rad - metricZOffset * metricZOffset;
			
			drawCursor.setCoord(2, zVoxLoc);
			
			if (diffy > 0) {
				float circleRadiusForThisZ = (float) (Math.sqrt(diffy));
				drawCircle(contour, center, circleRadiusForThisZ*2, drawCursor);
			}
		}
	}
    
    private static void drawCircle(XMimContour contour, XMimNoxelPointF center, float diameterInMm, XMimNoxelPointI drawCursor) {
    	float[] noxSize = contour.getSpace().getNoxSize();
    	float rad = diameterInMm/2;
    	
    	int yVoxRadius = (int)Math.ceil(rad/noxSize[1]);
    	
    	float centerY = center.getCoord(1);
    	for (short dY = 0; dY <= yVoxRadius; dY++) {
			int yVoxLoc = Math.round(dY+centerY);
			float metricYOffset = (yVoxLoc-centerY)*noxSize[1];
			
			drawCursor.setCoord(1, yVoxLoc);
			float metricCircleRadiusForThisY = (float) Math.sqrt(rad * rad - metricYOffset * metricYOffset);
			
			float voxCircleRadiusForThisY = Math.round(metricCircleRadiusForThisY/noxSize[0]);
			
			drawCursor.setCoord(0, Math.round(center.getCoord(0)-voxCircleRadiusForThisY));
			
			contour.getData().setRange(drawCursor, true, Math.round(voxCircleRadiusForThisY*2));
			
			yVoxLoc = Math.round(-dY+centerY);
			drawCursor.setCoord(1, yVoxLoc);
			contour.getData().setRange(drawCursor, true, Math.round(voxCircleRadiusForThisY*2));
		}
    }
}
