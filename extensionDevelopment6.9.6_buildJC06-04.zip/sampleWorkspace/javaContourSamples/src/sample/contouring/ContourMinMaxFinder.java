package sample.contouring;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;

/**
 *	Find the minimum and maximum voxels from an image, constrained by a contour
 */
public class ContourMinMaxFinder {

	private XMimNoxelPointF minVolLocation;
	private XMimNoxelPointF maxVolLocation;
	
	private float min = Float.POSITIVE_INFINITY;
	private float max = Float.NEGATIVE_INFINITY;
	
	private XMimContour con;
	
	private XMimSession sess;
	
	public ContourMinMaxFinder(XMimSession sess, XMimContour tgt) {
		this.con = tgt;
		this.sess = sess;
		
		findEm();
	}
	
	private void findEm() {
		findMinMax(0,con.getSpace().createNoxelPoint().toRawDataLocation());
	}
	
	private void findMinMax(int dim, XMimNoxelPointI contourNoxel) {
		//data contains the mask of which voxels are inside the contour
		XMimMutableNDArray data = con.getData();
		
		int[] dims = data.getDims();
		
		//iterate through each voxel in this dimension
		for (int i=0; i<dims[dim]; i++) {
			contourNoxel.setCoord(dim, i);
			
			//since we don't know how many dimensions there are,
			//this function uses recursion to fill in all of the dimensions
			if (dim != dims.length-1) {
				findMinMax(dim+1, contourNoxel);
			} else {
				//once we have all of the dimensions set, we can check the contour
				boolean isInContour = data.getBooleanValue(contourNoxel);
				
				if (isInContour) {
					//this is the image the contour is associated with (e.g. the CT)
					XMimImage img = con.getMimImage();

					//the linker will allow us to convert between different spaces.  
					//In this case, we want to go from contour space to the image (e.g. the CT)
					XMimLinkController linker = sess.getLinker();

					//this just changes our integer point into a float one
					XMimNoxelPointF contourNoxelF = contourNoxel.toVoxelCenter();

					//convert the point from the contour space to the image space
					XMimNoxelPointF imageNoxelF = linker.toRawNoxel(contourNoxelF, img.getSpace());

					//acquire the value at this voxel
					float imgValue = img.getScaledData().getFloatValue(imageNoxelF.toRawDataLocation());
					
					if (imgValue < min) {
						min = imgValue;
						minVolLocation = imageNoxelF;
					}
					if (imgValue > max) {
						max = imgValue;
						maxVolLocation = imageNoxelF;
					}
					
				}
			}
		}
	}
	
	public float getMax() {
		return max;
	}
	public float getMin() {
		return min;
	}
	
	public XMimNoxelPointF getMaxLocation() {
		return maxVolLocation;
	}
	public XMimNoxelPointF getMinLocation() {
		return minVolLocation;
	}
}
