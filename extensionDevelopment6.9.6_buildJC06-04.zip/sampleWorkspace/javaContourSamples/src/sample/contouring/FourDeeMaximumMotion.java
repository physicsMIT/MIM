package sample.contouring;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.swing.JOptionPane;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.stats.XMim4DContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumeric4DContourStat;

public class FourDeeMaximumMotion {
	private static final String name = "4D Maximum Centroid Motion";
	private static final String desc = "Compute the maximum centroid motion of a dynamic contour";

	@XMimEntryPoint(
			name=name,
			author="Benjamin Horstman",
			category="Statistics",
			description=desc)
	public static Object[] run(final XMimSession sess, XMimContour con) {
		XMimImage image = con.getMimImage();
		final int[] dims = image.getRawData().getDims();

		if(dims.length < 4 || dims[3] <= 1) {
			sess.createLogger().error("insufficient image dimensions");
		}

		//MIM's log viewer (accessible by right-clicking the settings button in the top left)
		//will show the extension logs
		sess.createLogger().info("extension started");

		//A 4D statistic allows us to depend on stats from several 3D frames
		con.registerNew4DStat(new MaximumCenroidMotionStat(sess, dims));

		//we don't have any output, since we only register the statistic and return
		return new Object[0];
	}

	private static final class MaximumCenroidMotionStat implements XMimNumeric4DContourStat {
		private final XMimSession sess;
		private final int[] dims;
		//The javadoc for XMimContourStatId defines the built-in stats in MIM
		private final XMimContourStatId centroidX = new XMimContourStatId("CENTROIDX", "MIM");
		private final XMimContourStatId centroidY = new XMimContourStatId("CENTROIDY", "MIM");
		private final XMimContourStatId centroidZ = new XMimContourStatId("CENTROIDZ", "MIM");

		private MaximumCenroidMotionStat(XMimSession sess,
				int[] dims) {
			this.sess = sess;
			this.dims = dims;
		}

		@Override
		public String getStatName() {
			return name;
		}

		@Override
		public XMimContourStatId getStatId() {
			//the statId we return here can potentially allow other extensions
			//to be derived from our stat
			return new XMimContourStatId("MOTION_FOUR_DEE", "MIMEX");
		}

		@Override
		public Set<XMimContourStatId> getRequiredStats() {
			HashSet<XMimContourStatId> rv = new HashSet<XMimContourStatId>();

			//by telling MIM we depend on the centroid statistics,
			//we ensure that they will always be computed before our statistic
			rv.add(centroidX);
			rv.add(centroidY);
			rv.add(centroidZ);

			return rv;
		}

		@Override
		public String getAbbreviatedName() {
			return name;
		}

		@Override
		public Number computeResult(XMim4DContourStatContext context) {
			sess.createLogger().info("going to compute centroid maximum motion statistic");

			//first, lets go through and retrieve MIM's centroid calculations for each frame
			Map<Integer, float[]> centroids = new HashMap<Integer, float[]>();
			for(int w=0; w<dims[3]; w++) {
				sess.createLogger().info("going to retrieve w: " + w);
				Number xValue = context.getNumericResult(centroidX, w);
				Number yValue = context.getNumericResult(centroidY, w);
				Number zValue = context.getNumericResult(centroidZ, w);

				float[] value = new float[] {
						xValue.floatValue(),
						yValue.floatValue(),
						zValue.floatValue(),
				};
				sess.createLogger().info("retrieved for w: " + w + "\t" + value[0]+","+value[1]+","+value[2]);
				centroids.put(w, value);
			}

			//now, consider each pair of frames and find the maximum distance
			int frame1 = 0;
			int frame2 = 0;
			float maxDist = 0;
			for(int w1=0; w1<dims[3]; w1++) {
				for(int w2=w1+1; w2<dims[3]; w2++) {
					float[] first = centroids.get(w1);
					float[] second = centroids.get(w2);

					float xDist = first[0] - second[0];
					float yDist = first[1] - second[1];
					float zDist = first[2] - second[2];

					float t = xDist*xDist + yDist*yDist + zDist*zDist;
					float dist = (float) Math.sqrt(t);

					sess.createLogger().info("distance for w1: " + w1 +" w2: " + w2 + "===" +
							first[0]+","+first[1]+","+first[2]+", " + second[0]+","+second[1]+","+second[2]+"," + "===" + 
							dist);

					if(dist > maxDist) {
						maxDist = dist;
						frame1 = w1;
						frame2 = w2;
					}
				}
			}

			String message = "Maximum Distance was betweeen frame " + (frame1+1) + " and frame " + (frame2+1) + ": " +maxDist/10 + "cm";
			sess.createLogger().info(message);
			
			if(!Boolean.valueOf(System.getProperty("java.awt.headless"))) {
				//only display the result to the user if there is actually a user
				JOptionPane.showMessageDialog(null, message);
			} else {
				//we use this internally to perform automated testing
				//a user could also use the save statistics workflow command
				//during an assistant workflow
				System.setProperty("FOURDEEMAXIMUMMOTION", ""+maxDist);
			}

			return (Float) maxDist;
		}
	}
}