package sample.contouring;

import java.util.HashSet;
import java.util.Set;



import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.stats.XMimContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumericContourStat;

public class ContourStatSample {
	//these constants are built into MIM as defined in XMimContourStatId javadoc
	public final static XMimContourStatId tcId = new XMimContourStatId("TOTAL_COUNTS", "MIM");
	public final static XMimContourStatId regId = new XMimContourStatId("REGIONS", "MIM");
	
	private static final String statDesc = "Adds an Average Counts Per Region statistic to all contours.";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Average Counts Per Region",
			author="MIM",
			category="Statistics",
			description=statDesc)
	public static Object[] registerStat(XMimSession sess) {
		actuallyRegister(sess);

		//since we only want to register the stat, we can return nothing
		return new Object[0];
	}

	private static void actuallyRegister(XMimSession sess) {
		//register the statistic on the session so that all contours will receive it
		sess.registerNewStat(new XMimNumericContourStat() {
			@Override
			public String getStatName() {
				return "Avg Counts per Region";
			}
			@Override
			public XMimContourStatId getStatId() {
				//other extensions could refer to our statistic using this ID and namespace
				return new XMimContourStatId("ACpR", "MIMEX");
			}
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				//MIM will compute these stats before computing ours
				Set<XMimContourStatId> reqs = new HashSet<XMimContourStatId>();
				reqs.add(tcId);
				reqs.add(regId);
				return reqs;
			}
			@Override
			public String getAbbreviatedName() {
				//there is never enough space...
				return "ACpR";
			}
			@Override
			public Number computeResult(XMimContourStatContext context) {
				//do the actual work to compute the statistic
				Number totalCounts = context.getNumericResult(tcId);
				Number regionCount = context.getNumericResult(regId);
				return totalCounts.floatValue()/regionCount.floatValue();
			}
		});
	}
	
}
