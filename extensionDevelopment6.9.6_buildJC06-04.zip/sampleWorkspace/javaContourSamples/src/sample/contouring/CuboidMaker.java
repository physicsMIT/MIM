package sample.contouring;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimSeriesView;

public class CuboidMaker {

	private static final String contourCuboidDesc = "Draws a roughly cuboid contour in the centered on the crosshairs with specified volume in ml and side ratios";
	
	@XMimEntryPoint(name="Draw Cuboid at Crosshairs Proportions", author="MIM", category="Contouring", description=contourCuboidDesc)
	public static Object[] run(XMimSession sess, XMimSeriesView img, String ConName, Double volumeML, Double lengthRatio, Double widthRatio, Double heightRatio) {
		XMimContour con = img.getImage().createNewContour(ConName);
		XMimNoxelPointF crosshairPosImgSpace = img.getCrosshairLocation();
		XMimNoxelPointF crosshairPosContourSpace = sess.getLinker().convertPoint(crosshairPosImgSpace, con.getSpace(), crosshairPosImgSpace.getCoordSystem()).toNoxel();
		
		drawCuboid(con, crosshairPosContourSpace, volumeML, lengthRatio, widthRatio, heightRatio);
		con.redrawCompletely();
		
		return null;
	}
	
	public static void drawCuboid(XMimContour contour, XMimNoxelPointF center, double volumeML, double lengthRatio, double widthRatio, double heightRatio) {
		float[] noxSize = contour.getSpace().getNoxSize();
		double[] normRatios = new double[3];
		double[] noxDims = new double[3];
		
		// Normalize the ratios to be ratios of the smallest dimension
		List<Double> ratioList = Arrays.asList(lengthRatio, widthRatio, heightRatio);
		double minRatio = Collections.min(ratioList);
		
		normRatios[0] = lengthRatio / minRatio;
		normRatios[1] = widthRatio / minRatio;
		normRatios[2] = heightRatio / minRatio;
		
		// solve for the length of the smallest dimension in millimeters
		double mLTom3 = Math.pow(10, -6);  // Unit conversions
		double mTomm = 1000;
		double minDimensionMM = Math.cbrt(volumeML / normRatios[0] / normRatios[1] / normRatios[2] * mLTom3) * mTomm;
		
		// Convert to noxels
		for (int i = 0; i < noxDims.length; i++) {
			noxDims[i] = normRatios[i] * minDimensionMM / noxSize[i];
		}
		
		// Optimize dimension rounding to minimize volume error
		double targetVol = noxDims[0] * noxDims[1] * noxDims[2];
		double testVol;
		double diff = Double.MAX_VALUE;
		double testDiff;
		
		// Truncate double values
		int[] bestDims = new int[3];
		for (int i = 0; i < noxDims.length; i++) {
			noxDims[i] = Math.floor(noxDims[i]);
		}
		
		// Test all integer combinations for closest volume
		for (int x = 0; x < 2; x++) {
			for (int y = 0; y < 2; y++) {
				for (int z =0; z < 2; z++) {
					testVol = (noxDims[0] + x) * (noxDims[1] + y) * (noxDims[2] + z);
					testDiff = Math.abs(targetVol -testVol);
					
					if (testDiff < diff) {
						diff = testDiff;
						bestDims[0] = (int) (noxDims[0] + x);
						bestDims[1] = (int) (noxDims[1] + y);
						bestDims[2] = (int) (noxDims[2] + z);
					}
				}
			}
		}
		
		// Create a point to save memory on allocations
		XMimNoxelPointI drawCursor = contour.getMimImage().createNoxelPointI();
    	float centerZ = center.getCoord(2);
    	
    	// For each axial slice, draw a rectangle of the appropriate size
    	for (int dZ = 0; dZ * 2 <= bestDims[2]; dZ++) {
    		int zVoxLoc = Math.round(centerZ + dZ);
    		drawCursor.setCoord(2, zVoxLoc);
    		
    		drawRectangle(contour, center, bestDims[0], bestDims[1], drawCursor);
    		
    		if (dZ * 2 + 1 <= bestDims[2]) {
	    		zVoxLoc = Math.round(centerZ - dZ);
	    		drawCursor.setCoord(2, zVoxLoc);
	    		
	    		drawRectangle(contour, center, bestDims[0], bestDims[1], drawCursor);
    		}
    	}
	}
	
	private static void drawRectangle(XMimContour contour, XMimNoxelPointF center, int lengthVox, int widthVox, XMimNoxelPointI drawCursor) {
    	float centerY = center.getCoord(1);
    	for (int dY = 0; dY * 2 <= widthVox; dY++) {
			int yVoxLoc = Math.round(centerY + dY);
			drawCursor.setCoord(1, yVoxLoc);
			drawCursor.setCoord(0, (int) Math.floor(center.getCoord(0)-lengthVox/2.0));
			
			contour.getData().setRange(drawCursor, true, (int) (Math.floor(lengthVox/2.0) + Math.ceil(lengthVox/2.0)));
			
			if (dY * 2 + 1 <= widthVox) {
				yVoxLoc = Math.round(centerY - dY);
				drawCursor.setCoord(1, yVoxLoc);
				contour.getData().setRange(drawCursor, true, (int) (Math.floor(lengthVox/2.0) + Math.ceil(lengthVox/2.0)));
			}
		}
	}
}