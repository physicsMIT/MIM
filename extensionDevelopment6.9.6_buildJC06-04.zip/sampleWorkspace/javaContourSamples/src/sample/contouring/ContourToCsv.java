package sample.contouring;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.swing.JFileChooser;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.data.XMimRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimCoordSystem;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.points.XMimPointFactory;
import com.mimvista.external.series.XMimDose;
import com.mimvista.external.series.XMimImage;

/**
 * 	The ContourToCsv extension outputs a csv file which contains a list of all of the scaled values of the multiplied voxels
 * 	contained within a selected contour.  It will also output the dose, if supplied<br/><br/>
 * 
 */
public class ContourToCsv {
	XMimSession session;
	
	public ContourToCsv(XMimSession session) {
		this.session = session;
	}
	
	private static final String contourDoseDesc = "Outputs a CSV file that contains a list of all of the scaled values of the"+
			" multiplied voxels contained within the selected contour, and the associated dose";
	
	@XMimEntryPoint(
			name="Contour & Dose to CSV", 
			author="MIM", 
			category="Dose",
			description=contourDoseDesc)
	public static Object[] run(XMimSession sess, XMimContour con, XMimDose dose) {
		//First, show a JFileChooser to let the user decide where to output the CSV file
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogType(JFileChooser.SAVE_DIALOG);
		jfc.setSelectedFile(new File("contourData.csv"));
		jfc.showSaveDialog(null);
		
		File file = jfc.getSelectedFile();
		
		if (file == null) {
			return null;
		}

		//create the object, and then start the actual writing process
 		ContourToCsv csv = new ContourToCsv(sess);
		csv.writeCsv(con, dose, file);

		//since we have no outputs back to MIM, we return an empty array
		return new Object[0];
	}
	
	public void writeCsv(final XMimContour contour, final XMimImage dose, File csvFile) {
		XMimLogger logger = session.createLogger();
		
		//XMimLogger can be used to output debugging information.
		//Extension logs go into the MIM log folder in a special directory
		logger.debug("csv path "+csvFile.getAbsolutePath());
		
		BufferedWriter bo = null;
		try {
			//Create a writer for file output
			bo = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvFile)));
			
			//this is the image the contour is associated with (e.g. the CT)
			XMimImage image = contour.getMimImage();
			
			//links and points for converting between different spaces
			XMimLinkController link = session.getLinker();
			XMimPointFactory pf = session.getPointFactory();
			
			final XMimNoxelPointF imageNoxel = image.createNoxelPointF();
			final XMimCoordSystem dcm = pf.getDicomCoordSystem();
			XMimPointF imageDicom = pf.createPoint(
					image.getSpace(), 
					dcm,
					new float[image.getRawData().getDims().length]);
			XMimNoxelPointF doseNoxelF = null;
			XMimNoxelPointI doseNoxelI = null;
			if(dose != null) {
				doseNoxelF = dose.createNoxelPointF();
				doseNoxelI = doseNoxelF.toRawDataLocation();
			}
			
			//a few extra points, used to reduce memory allocation
			XMimPointF conPoint = link.toRawNoxel(imageNoxel, contour.getSpace());
			XMimNoxelPointF contourNoxelF = conPoint.getCoordSystem().toRawNoxel(conPoint);
			XMimNoxelPointI contourNoxelI = contourNoxelF.toRawDataLocation();
			
			//scaledImgData represents the raw voxels, scaled to the actual units (e.g. HU)
			XMimNDArray scaledImgData = image.getScaledData();
			
			writeHeadings(bo, scaledImgData, dose);
			
			//XMimRLEIterator returns the RLE compressed version of one
			//x-axis line of the contour boolean mask.  So, we calculate the on and off position,
			//and then output each voxel along that section
			for (XMimRLEIterator lineIter : contour.getData().getRleIterable()) {
				int start = -1;
				
				while (lineIter.hasNext()) {
					//find the location of the next change in the mask, and set it into contourNoxelI
					lineIter.advanceToNextNewValue(contourNoxelI);
					
					//based on getBoolean, determine if this is a start or end
					int end = -1;
					if (lineIter.getBoolean()) {
						start = contourNoxelI.getCoord(0);
						if (!lineIter.hasNext()) {
							end = lineIter.getCurrentLine().getDims()[0];
						}
					} else {
						end = contourNoxelI.getCoord(0);
					}
					
					//once we have a start and an end, write this section
					if (start != -1 && end != -1) {
						for(int i=start; i<end; i++) {
							contourNoxelI.setCoord(0, i);
							
							//this just changes our integer point into a float one
							contourNoxelI.toVoxelCenter(contourNoxelF);

							//convert the point from the contour space to the image space
							link.toRawNoxel(contourNoxelF, image.getSpace(), imageNoxel);
							
							//acquire the value at this voxel
							float val = scaledImgData.getFloatValue(imageNoxel.toRawDataLocation());
							
							//since we want to output DICOM coordinates, not voxel, convert the point
							link.convertPoint(imageNoxel, null, dcm, imageDicom);

							//write the coordinate and the image value
							bo.write(imageDicom.getCoord(0)+","+imageDicom.getCoord(1)+","+imageDicom.getCoord(2)+","+val+",");
							
							if(dose != null) {
								//similar to the convertPoint call above, find the location in the dose space
								link.toRawNoxel(contourNoxelF, dose.getSpace(), doseNoxelF);
								doseNoxelF.toRawDataLocation(doseNoxelI);
								
								//here, the scaled data will have the units of Gy
								XMimNDArray scaledData = dose.getScaledData();
								
								//if the point is inside the dose, then write the dose
								//otherwise, we will output zero
								double value;
								if(scaledData.isPointInArray(doseNoxelI)) {
									value = scaledData.getDoubleValue(doseNoxelI);
								} else {
									value = 0;
								}
								bo.write(value + ",");
							}
							
							bo.write("\n");
						}
						start = -1;
					}
				}
			}

			logger.debug("Done writing csv.");
		} catch (Exception e) {
			logger.error("Unexpected IO exception", e);
		} finally {
			if (bo != null)try {bo.close();} catch (IOException e) {}
		}
	}

	/**
	 * 	Write appropriate headings to the first line of the CSV file
	 * 
	 * @param bo
	 * @param scaledImgData
	 * @param dose
	 * @throws IOException
	 */
	private void writeHeadings(
			BufferedWriter bo,
			XMimNDArray scaledImgData,
			final XMimImage dose) throws IOException {
		String[] spatialLbls = new String[]{"Dicom X","Dicom Y","Dicom Z","Frame Number"};
		
		for (int i=0; i<scaledImgData.getDimensionCount(); i++) {
			bo.write(spatialLbls[i]+",");
		}
		bo.write("Value ("+scaledImgData.getUnit()+"),");
		if(dose != null) {
			bo.write("Dose Value (Gy)");
		}
		bo.write("\n");
	}
}
