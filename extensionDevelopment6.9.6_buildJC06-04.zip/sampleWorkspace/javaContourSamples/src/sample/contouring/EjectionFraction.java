package sample.contouring;

import java.util.HashSet;
import java.util.Set;

import javax.swing.JOptionPane;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.stats.XMim4DContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumeric4DContourStat;
import com.mimvista.external.stats.XMimNumeric4DContourStat.XMimAbstractNumeric4DContourStat;

public class EjectionFraction {

	
	private static final String stat4dDesc = "Adds the 'Ejection Fraction' stat to the 4D contour you provide.";
	
	@XMimEntryPoint(name="Ejection Fraction", author="MIM", category="Statistics", description=stat4dDesc)
	public static Object[] register4dStat(XMimSession sess, final XMimContour tgtCon) {
		
		if (tgtCon.getDims().length < 4) {
			JOptionPane.showMessageDialog(null, "Stat registration failed, the provided contour was not 4D.");
			return null;
		}
		
		//since MIM's statistic viewer doesn't support 4D statistics in all versions,
		//we'll create our own window
		final StatDisplayer sd = new StatDisplayer(sess.getAppInstance().getMainWindow());
		sd.setVisible(true);
		
		tgtCon.registerNew4DStat(createEjectionFractionStat(sd));
		
		//since we're just registering a statistic, we have no ouput
		return new Object[0];
	}

	//for an introduction to 4D statistics, refer to the FourDeeMaximumMotion class
	private static XMimNumeric4DContourStat createEjectionFractionStat(final StatDisplayer sd) {
		return new XMimAbstractNumeric4DContourStat() {
			@Override
			public String getStatName() {
				return "Ejection Fraction";
			}
			
			@Override
			public XMimContourStatId getStatId() {
				return new XMimContourStatId("EJECT_FRAC", "MY_EXT");
			}
			
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				//Note that we don't return the 3D Max stat here. For 4D stats, you can assume that all 3D stats for each frame
				//have already been computed by the time your 'computeResult' method is called.
				return new HashSet<XMimContourStatId>();
			}
			
			@Override
			public String getAbbreviatedName() {
				return "EjtFrc";
			}
			
			@Override
			public boolean shouldRemove() {
				//Remove the stat once the stat window is closed since it doesn't show up anywhere else.
				return !sd.isVisible();
			}
			
			@Override
			public void handleStatInvalidation(XMimContour dirtiedContour) {
				sd.updateStat(this, dirtiedContour, "Computing...");
			}
			
			@Override
			public Number computeResult(XMim4DContourStatContext context) {
				int frameCount = context.getContour().getDims()[3];
				
				float maxTotal = -Float.MAX_VALUE;
				float minTotal = Float.MAX_VALUE;
				
				int maxFrm = -1;
				int minFrm = -1;
				
				for (int i=0; i<frameCount; i++) {
					Number tcResult = context.getNumericResult(ContourStatSample.tcId, i);
					
					if (tcResult == null) {
						//Null result for a frame means it's empty
						continue;
					}
					
					float frmTotal = tcResult.floatValue();
					if (frmTotal > maxTotal) {
						maxTotal = frmTotal;
						maxFrm = i;
					}
				}
				
				float ejectionFraction;
				if (maxFrm == -1) {
					ejectionFraction = Float.NaN;
				} else {
					
					for (int i=0; i<frameCount; i++) {
						Number tcResult = context.getNumericResult(ContourStatSample.tcId, i);
						
						if (i <= maxFrm) {
							//Min must be after max
							continue;
						}
						
						if (tcResult == null) {
							//Null result for a frame means it's empty
							continue;
						}
						
						if (tcResult.intValue() == 0) {
							//Some scans have blank frames; assume that the frame is bogus if the contour contains nothing 
							continue;
						}
						
						float frmTotal = tcResult.floatValue();
						if (frmTotal < minTotal) {
							minTotal = frmTotal;
							minFrm = i;
						}
					}
					
					if (minFrm == -1) {
						ejectionFraction = Float.NaN;
					} else {
						ejectionFraction = (maxTotal - minTotal) / maxTotal;
					}
				}
				
				sd.updateStat(this, context.getContour(), String.valueOf(ejectionFraction));
				
				return ejectionFraction;
			}
		};
	}
	
}
