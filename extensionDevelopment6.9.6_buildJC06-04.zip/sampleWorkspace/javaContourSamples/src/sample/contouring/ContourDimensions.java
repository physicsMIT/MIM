package sample.contouring;

import javax.swing.JOptionPane;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimCoordSystem;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.points.XMimPointFactory;
import com.mimvista.external.series.XMimImage;

public class ContourDimensions {
	private static final String dimensionDesc = "Finds the maximum dimensions of the currently active contour.";
	
	@XMimEntryPoint(
			name="Contour - Maximum Orthogonal Dimensions",
			author="James Fitzpatrick",
			category="Contouring",
			institution="MIM Software, inc.",
			version="1.0",
			description=dimensionDesc)
	public static Object[] runOnSessionContour(XMimSession session, XMimContour Contour){
		ContourDimensions.process(session, Contour);
		return new Object[0];
	}
	
	static float[] conversionArray;
	
	public static void process(XMimSession session, XMimContour Contour){
		XMimImage image = Contour.getMimImage();
		conversionArray = Contour.getNoxelSizeInMm();
		float[] vals = calculateOrthogonalMaxima(session, image, Contour);
		
		if(vals != null){
			// We need to add the extra conversion factor here as we
			// need to account for the area of each noxel. 
			
			JOptionPane.showMessageDialog(null, 
					"Sagittal: "+ (vals[3] - vals[0] + conversionArray[0] ) + " mm"+
						"\nCoronal: "+ (vals[4] - vals[1] + conversionArray[1]) + " mm"+
						"\nTransverse: " + (vals[5] - vals[2] + conversionArray[2] + " mm"), 
					"Orthogonal Extents for " + Contour.getInfo().getName(), 
					JOptionPane.INFORMATION_MESSAGE );
		}
		
		return;
		
	}

	private static float[] calculateOrthogonalMaxima(
			XMimSession session, 
			XMimImage image,
			XMimContour contour) {
				
		// Linker to get us from one space to another
		// In this case from contour to image space
		XMimLinkController linker = session.getLinker();
		XMimPointFactory pf = session.getPointFactory();
		
		XMimNoxelPointF imageNoxel = image.createNoxelPointF();
		final XMimCoordSystem dcm = pf.getDicomCoordSystem();
		XMimPointF imageDicom = pf.createPoint(
				image.getSpace(), 
				dcm,
				new float[image.getRawData().getDims().length]);
		
		//a few extra points, used to reduce memory allocation
		XMimPointF conPoint = linker.toRawNoxel(imageNoxel, contour.getSpace());
		XMimNoxelPointF contourNoxelF = conPoint.getCoordSystem().toRawNoxel(conPoint);
		XMimNoxelPointI contourNoxelI = contourNoxelF.toRawDataLocation();
		
		
		float[] min = {Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE};
		float[] max = {Float.MIN_VALUE, Float.MIN_VALUE, Float.MIN_VALUE};

		// This algorithm looks at the end points of each line of the contour 
		// and compares their x,y, and z values to the minimum/maximum global
		// values. 
		
		//XMimRLEIterator returns the RLE compressed version of one
		//x-axis line of the contour boolean mask.  
		for (XMimRLEIterator lineIter : contour.getData().getRleIterable()) {
			int start = -1;
			
			while (lineIter.hasNext()) {
				//find the location of the next change in the mask, and set it into contourNoxelI
				lineIter.advanceToNextNewValue(contourNoxelI);
				
				//based on getBoolean, determine if this is a start or end
				int end = -1;
				if (lineIter.getBoolean()) {
					start = contourNoxelI.getCoord(0);
					if (!lineIter.hasNext()) {
						end = lineIter.getCurrentLine().getDims()[0];
					}
				} else {
					end = contourNoxelI.getCoord(0);
				}
				
				if(start!=-1 && end != -1){
					
					// We only need to check the largest and smallest values of X
					// on the line as all of their Y and Z values are identical.
					contourNoxelI.setCoord(0,start);
					
					//this just changes our integer point into a float one
					contourNoxelI.toVoxelCenter(contourNoxelF);
						
					//convert the point from the contour space to the image space
					linker.toRawNoxel(contourNoxelF, image.getSpace(), imageNoxel);
				
					//since we want to output DICOM coordinates, not voxel, convert the point
					linker.convertPoint(imageNoxel, null, dcm, imageDicom);
					
					for(int j = 0; j<=2 ; j++){
						
						// Check to see if the noxel in question has a larger coordinate than 
						// the previously largest coordinate in x,y,z directions
						if(contourNoxelF.getCoord(j) * conversionArray[j] > max[j]){
							max[j] = contourNoxelF.getCoord(j) * conversionArray[j];
						}
						
						if(contourNoxelF.getCoord(j) * conversionArray[j] < min[j]){
							min[j] = contourNoxelF.getCoord(j)* conversionArray[j];
						}
						
					}			
					
					// We really only need to check 
					
					contourNoxelI.setCoord(0,end-1);
					
					//this just changes our integer point into a float one
					contourNoxelI.toVoxelCenter(contourNoxelF);
										
					if(contourNoxelF.getCoord(0) * conversionArray[0] > max[0]){
						max[0] = contourNoxelF.getCoord(0) * conversionArray[0];
					}
					
					start = -1;
				}
			}
		}
		
		// Return our min and max values.
		float[] vals = new float[6];
		
		for(int i = 0; i<max.length;i++){
			vals[i] = min[i];
			vals[i+3] = max[i];
		}		
		return vals;
	}
}
