package sample.contouring;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.swing.JFileChooser;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.series.XMimDose;
import com.mimvista.external.series.XMimImage;

/**
 * 	The ContourToCsvSimple extension outputs a csv file which contains a list of all of the scaled values of the multiplied voxels
 * 	contained within a selected contour.  It will also output the dose, if supplied<br/><br/>
 * 
 * 	This version is a simplified version of {@link ContourToCsv}, suitable for demos.
 * 	Thus, the performance will be inferior.
 *
 */
public class ContourToCsvSimple {
	XMimSession session;
	
	public ContourToCsvSimple(XMimSession session) {
		this.session = session;
	}
	
	@SuppressWarnings("unused")
	private static final String contourDoseDesc = "Outputs a CSV file that contains a list of all of the scaled values of the"+
			" multiplied voxels contained within the selected contour, and the associated dose.";
	
//	by default, we only install the optimized version.  Uncomment this line to install the simple version
//	@XMimEntryPoint(
//			name="Contour & dose to CSV Simple",
//			author="MIM",
//			description=contourDoseDesc)
	public static Object[] run(XMimSession sess, XMimContour con, XMimDose dose) {
		//First, show a JFileChooser to let the user decide where to output the CSV file
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogType(JFileChooser.SAVE_DIALOG);
		jfc.setSelectedFile(new File("contourData.csv"));
		jfc.showSaveDialog(null);
		
		File file = jfc.getSelectedFile();
		
		if (file == null) {
			return null;
		}
		
		//create the object, and then start the actual writing process
 		ContourToCsv csv = new ContourToCsv(sess);
		csv.writeCsv(con, dose, file);
		
		//since we have no outputs back to MIM, we return an empty array
		return new Object[0];
	}
	
	public void writeCsv(final XMimContour contour, final XMimImage dose, File csvFile) {
		XMimLogger logger = session.createLogger();
		
		//XMimLogger can be used to output debugging information.
		//Extension logs go into the MIM log folder in a special directory
		logger.debug("csv path "+csvFile.getAbsolutePath());
		
		BufferedWriter bo = null;
		try {
			//Create a writer for file output
			bo = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvFile)));
			
			//this is the image the contour is associated with (e.g. the CT)
			XMimImage image = contour.getMimImage();
			
			//scaledImgData represents the raw voxels, scaled to the actual units (e.g. HU)
			XMimNDArray scaledImgData = image.getScaledData();
			
			writeHeadings(bo, scaledImgData, dose);
			
			//create a point at the multiplied voxel zero for the contour
			int[] dims = contour.getDims();
			XMimNoxelPointI contourNoxelF = session.getPointFactory().createNoxelPointI(
					contour.getSpace(), 
					new int[contour.getDims().length]);
			
			//another for the image
			XMimNoxelPointF imageNoxel = image.createNoxelPointF();
			
			//and another for the dose
			XMimNoxelPointF doseNoxel = dose.createNoxelPointF();
			
			//The preceeding two points are only float-type because of
			//how we will convert the locations between different spaces
			
			//the linker will allow us to convert between different spaces.  
			//In this case, we want to go from contour space to the image (e.g. the CT) and dose spaces
			XMimLinkController linker = session.getLinker();
			
			//a DICOM position inside the original image
			//note that we will use noxel (voxel) coordinates for the contour and dose,
			//but we want to output DICOM to the CSV, so this point has a different coordinate system
			XMimPointF dcmPos = session.getPointFactory().createPoint(
					image.getSpace(), 
					session.getPointFactory().getDicomCoordSystem(), 
					new float[contour.getDims().length]);
			
			//this 3D for loop is the main part which is improved in the optimized version
			//basically, we can refrain from checking every potential area
			//that could be inside the contour, and instead just go through the parts
			//that mim knows are included
			//Additionally, this version of the for loop is restricted to 3D data
			for(int z=0; z<dims[2]; z++) {
				contourNoxelF.setCoord(2, z);
				
				for(int y=0; y<dims[1]; y++) {
					contourNoxelF.setCoord(1, y);
					
					for(int x=0; x<dims[0]; x++) {
						contourNoxelF.setCoord(0, x);
						
						//if we are not inside the contour, we do not output anything
						if(!contour.getData().getBooleanValue(contourNoxelF)) {
							continue;
						}

						//convert the point from the contour space to the image space
						linker.convertPoint(
								contourNoxelF.toVoxelCenter(), 
								image.getSpace(), 
								null,
								imageNoxel);
						
						//access the image value for this location
						float val = scaledImgData.getFloatValue(imageNoxel.toRawDataLocation());
						
						//since we want to output DICOM coordinates, not voxel, convert the point
						linker.convertPoint(imageNoxel, null, dcmPos.getCoordSystem(), dcmPos);
						
						//write the coordinate and the image value
						bo.write(dcmPos.getCoord(0)+","+dcmPos.getCoord(1)+","+dcmPos.getCoord(2)+","+val+",");
						
						if(dose != null) {
							//similar to the convertPoint call above, find the location in the dose space
							linker.toRawNoxel(imageNoxel, dose.getSpace(), doseNoxel);
							XMimNoxelPointI doseDataPos = doseNoxel.toRawDataLocation();
							
							//here, the scaled data will have the units of Gy
							XMimNDArray scaledData = dose.getScaledData();
							
							//if the point is inside the dose, then write the dose
							//otherwise, we will output zero
							double value;
							if(scaledData.isPointInArray(doseDataPos)) {
								value = scaledData.getDoubleValue(doseDataPos);
							} else {
								value = 0;
							}
							bo.write(value + ",");
						}
						
						bo.write("\n");
					}
				}
			}

			logger.debug("Done writing csv.");
		} catch (Exception e) {
			logger.error("Unexpected IO exception", e);
		} finally {
			if (bo != null)try {bo.close();} catch (IOException e) {}
		}
	}

	/**
	 * 	Write appropriate headings to the first line of the CSV file
	 * 
	 * @param bo
	 * @param scaledImgData
	 * @param dose
	 * @throws IOException
	 */
	private void writeHeadings(
			BufferedWriter bo,
			XMimNDArray scaledImgData,
			final XMimImage dose) throws IOException {
		String[] spatialLbls = new String[]{"Dicom X","Dicom Y","Dicom Z","Frame Number"};
		
		for (int i=0; i<scaledImgData.getDimensionCount(); i++) {
			bo.write(spatialLbls[i]+",");
		}
		bo.write("Value ("+scaledImgData.getUnit()+"),");
		if(dose != null) {
			bo.write("Dose Value (Gy)");
		}
		bo.write("\n");
	}
}
