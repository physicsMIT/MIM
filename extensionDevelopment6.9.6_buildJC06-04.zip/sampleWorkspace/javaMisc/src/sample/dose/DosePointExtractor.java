package sample.dose;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

import javax.swing.JFileChooser;

import com.mimvista.external.algorithms.XMimInterpolator;
import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.contouring.XMimPointOverlay;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.data.XMimRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimImageSpace;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.series.XMimDose;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableDose;
import com.mimvista.external.series.XMimSeriesView;

public class DosePointExtractor {

	private static final String desc = "Exports to a .csv file the dose value at the point contours of a given volume.";

	@XMimEntryPoint(
			name="Dose Point Contour Extractor",
			author="Paul Jacobs",
			description=desc, 
			website="www.mimsoftware.com",
			outputTypes={},
			category="Dose", 
			institution="MIM Software", 
			version="1.0")
	public static Object[] runOnSession(XMimSession session, XMimImage series, XMimDose doseToProcess) {
		DosePointExtractor dp = new DosePointExtractor(session, series, doseToProcess);
		try {
			dp.process();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new Object[0];

	}

	XMimSession sess;
	XMimDose dose;
	XMimImage vol;
	

	
	public DosePointExtractor(XMimSession sess, XMimImage series, XMimDose dose) {
		this.sess = sess;
		this.dose = dose;
		this.vol = series;
	}
	
	private void process() throws IOException{ 
		
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogType(JFileChooser.SAVE_DIALOG);
		jfc.setSelectedFile(new File("contourData.csv"));
		jfc.showSaveDialog(null);

		File file = jfc.getSelectedFile();

		if (file == null) {
			return;
		}
		
		BufferedWriter bo = null; 
		try{
			bo = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));

			writeHeadings(bo);


			XMimLinkController linker = sess.getLinker();
			XMimNDArray scaledDose = dose.getScaledData();
			
			XMimImageSpace doseSpace = dose.getSpace();
			XMimInterpolator interp = sess.getInterpolatorFactory().getInterpolatorForVolume(scaledDose);


			for(XMimPointOverlay po : vol.getPointOverlays()){
				for(XMimPointF p : po.getData()){
					
					XMimPointF dosePoint = sess.getPointFactory().createPoint(doseSpace,
							sess.getPointFactory().getDicomCoordSystem(), p.toArray());
					XMimNoxelPointF vp = dosePoint.toNoxel();

					float val;
					try{
						val = interp.getTrilinearValue(vp);
					} catch (Throwable t){
						StringWriter s = new StringWriter();
						t.printStackTrace(new PrintWriter(s));
						s.flush();
						bo.write(s.toString() + "\n");
						//bo.write(t.getMessage());

						val = 0;
					}
					//bo.write(po.getInfo().getName() + "," + p.getCoord(0) + "," + p.getCoord(1) + "," + 
					//		p.getCoord(2) + "," + val + '\n');
					bo.write(po.getInfo().getName() + "," + vp.getCoord(0) + "," + vp.getCoord(1) + "," + 
							vp.getCoord(2) + "," + val + '\n');
					
				}
			}
		}finally{
			if(bo != null){
				bo.close();
			}
		}
	}
	
	private void writeHeadings(BufferedWriter bo) throws IOException {
		String[] labels = new String[]{"Name, Dicom X","Dicom Y","Dicom Z","Dose(Gy)"};
		
		for (int i=0; i<labels.length; i++) {
			bo.write(labels[i]+",");
		}
		bo.write("\n");
	}
	
	
}
