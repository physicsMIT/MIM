package sample.imaging;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableImage;
import com.mimvista.external.series.XMimSeriesView;

public class Normalizer {
	private static final String desc = "Creates a 'normalized' copy of the selected image";
	
	@XMimEntryPoint(name="Normalizer", author="MIM", description=desc, category="Utilities", outputTypes={XMimImage.class})
	public Object[] runOnSession(XMimSession session, XMimImage view) {
		XMimMutableImage result = view.getMutableCopy();
		Normalizer.normalizeImage(result, 0, result.createNoxelPointI());
		
		XMimSeriesView ret = session.addImageAndReturnView(result, "Normalized Vol");
		
		return new Object[]{ret};
	}

	public static void normalizeImage(XMimMutableImage img, int dim, XMimNoxelPointI nox) {
		
		short min = Short.MAX_VALUE;
		short max = Short.MIN_VALUE;
		
		short[] minMax = new short[]{min,max};
		getMinMax(img, dim, nox, minMax);
		
		float newIntercept = -minMax[0];
		float newSlope = (100-newIntercept)/minMax[1];
		
		
		img.getInfo().setRescaleSlope(newSlope);
		img.getInfo().setRescaleIntercept(newIntercept);
		img.getInfo().setUnits("NORMs");
	}
	
	public static void getMinMax(XMimMutableImage img, int dim, XMimNoxelPointI nox, short[] minMax) {
		int[] dims = img.getRawData().getDims();
		for (int i=0; i<dims[dim]; i++) {
			nox.setCoord(dim, i);
			if (dim == dims.length-1) {
				short val = img.getRawData().getShortValue(nox);
				if (val < minMax[0]) {
					minMax[0] = val;
				}
				if (val > minMax[1]) {
					minMax[1] = val;
				}
			} else {
				getMinMax(img, dim+1, nox, minMax);
			}
		}
	}
	
}
