package sample.dicom;

import java.util.Collection;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimDicomInfo;
import com.mimvista.external.series.XMimDicomSeries;

public class BeamReader {

	private static final String desc = "Logs the beam names and descriptions from any RTPLANs that have been loaded into " +
			"the current session.";
	
	@XMimEntryPoint(name="Beam Reader", author="MIM", description=desc, category="Utilities", outputTypes={})
	public Object[] runOnSession(XMimSession session) {
		//MIM does not store RTPLAN DICOM information by default, so the STORE_EXTRA_DICOM preference in extensions.txt must be
		//enabled for this extension to work properly.
		
		XMimLogger logger = session.createLogger();
		
		Collection<XMimDicomSeries> seriesList = session.getAllDicomSeries();
		
		int planNum = 0;
		for (XMimDicomSeries s : seriesList) {
			if (!isRtPlan(s)) {
				continue;
			}
			
			logger.info("Reading RTPLAN #"+(planNum+1));
			logBeamInfo(s, logger);
			planNum++;
		}
		
		if (planNum == 0) {
			logger.info("No plans found.  Ensure that STORE_EXTRA_DICOM in extensions.txt is enabled.");
		}
		
		return new Object[]{};
	}
	
	private void logBeamInfo(XMimDicomSeries series, XMimLogger log) {
		if (series.getDicomInfos().isEmpty()) {
			return;
		}
		
		XMimDicomInfo firstDicom = series.getDicomInfos().iterator().next();
		
		Object[] beamSeq = (Object[])firstDicom.getValueArrayByName("BeamSequence");
		
		if (beamSeq == null) {
			log.info("RTPLAN has no Beam Sequence. Skipping.");
			return;
		}
		
		for (int i=0; i<beamSeq.length; i++) {
			XMimDicomInfo beam = (XMimDicomInfo)beamSeq[i];
			
			String name = (String)beam.getValueByName("BeamName");
			String desc = (String)beam.getValueByName("BeamDescription");
			
			StringBuilder msg = new StringBuilder();
			msg.append("Beam #");
			msg.append(i+1);
			msg.append(":");
			if (name != null) {
				msg.append(" Name: ");
				msg.append(name);
			}
			if (desc != null) {
				msg.append(" Description: ");
				msg.append(desc);
			}
			log.info(msg.toString());
		}
	}
	
	private boolean isRtPlan(XMimDicomSeries series) {
		if (series.getDicomInfos().isEmpty()) {
			return false;
		}
		XMimDicomInfo firstDicom = series.getDicomInfos().iterator().next();
		
		String mod = (String)firstDicom.getValueByName("Modality");
		
		return "RTPLAN".equalsIgnoreCase(mod);
	}
	
}
