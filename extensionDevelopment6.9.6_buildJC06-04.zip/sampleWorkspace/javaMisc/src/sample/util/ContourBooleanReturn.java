package sample.util;

import javax.swing.JOptionPane;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimSeriesView;

public class ContourBooleanReturn {
	private static final String desc = "Asks the user yes or no, and returns an empty contour to mean no and a non-empty one for yes";
	
	//this extension only exists to work around the inability to return a boolean in <= MIM 6.6.
	//MIM 6.7+ can return a boolean and don't need this complicated code
	@XMimEntryPoint(name="Contour Boolean Return", author="Ben Horstman", category="Utilities", description=desc, outputTypes={XMimContour.class})
	public static Object[] runOnSession(XMimSession session, XMimSeriesView image) {
		int yn = JOptionPane.showConfirmDialog(null, "Yes or no?", "Question", JOptionPane.YES_NO_OPTION);
		
		XMimContour rv;
		
		if(yn == JOptionPane.YES_OPTION) {
			rv = image.getImage().createNewContour("temporary");
		} else {
			rv = null;
		}
		
		return new Object[] {rv};
	}
}
