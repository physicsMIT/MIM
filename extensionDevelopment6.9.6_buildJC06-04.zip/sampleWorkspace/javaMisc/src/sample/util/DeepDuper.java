package sample.util;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimSeriesView;

public class DeepDuper {

	private static final String desc = "Outputs a deep copy of the volume you pass in.";
	
	@XMimEntryPoint(name="Deep Image Copy", author="Andy Lee", category="Utilities", description=desc, outputTypes={XMimSeriesView.class})
	public static Object[] runOnSession(XMimSession session, XMimSeriesView image) {
		XMimImage result = image.getImage().getMutableCopy();
		
		XMimSeriesView newView = session.addImageAndReturnView(result, image.getCustomName()+" (Copy)");
		
		return new Object[] {newView};
	}
	
}
