package sample.control;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;

/**
 * 	This extension calculates a conformity index (N ROI DICE coeffecient), as defined in:
 * 	Measuring the similarity of target volume delineations independent of the number of observers
 * 	(Erik Kouwenhoven et al)
 * 
 * @author bhorstman
 */
public class Launcher {

	private static final String desc = "Calculates a conformity index (N ROI DICE coeffecient), as defined by Erik Kouwenhoven et al";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Conformity Index (N ROI DICE coeffecient)",
			author="Benjamin P Horstman",
			category="Statistics",
			description=desc,
			outputTypes={})
	public static Object[] runOnSession(XMimSession session, XMimImage image) {
		String prefix = askForPrefix("");
		
		List<XMimContour> contours = findRelevantContours(image, prefix);
		
		if(contours.size() <= 1) {
			String message = "failed to find enough contours";
			JOptionPane.showMessageDialog(null, message);
			session.createLogger().error(message);
		} else {
			double dice = process(session, contours);
			
			JOptionPane.showMessageDialog(null, "Dice coefficient: " + dice);
			session.createLogger().debug("Dice coefficient: " + dice);
		}
		
		//Our @XMimEntryPoint says we return nothing, so do that here
		return new Object[] {};
	}
	
	private static String askForPrefix(String prefix) {
		String result = JOptionPane.showInputDialog("Please type the prefix of the contours to compare", "");
		
		return result;
	}

	private static List<XMimContour> findRelevantContours(XMimImage image, String prefix) {
		List<XMimContour> rv = new ArrayList<XMimContour>();
		
		for(XMimContour contour : image.getContours()) {
			if(contour.getInfo().getName().startsWith(prefix)) {
				rv.add(contour);
			}
		}
		
		return rv;
	}

	public static double process(XMimSession session, List<XMimContour> contours) {
		String s = "Going to process: ";
		for(XMimContour contour : contours) {
			s += contour.getInfo().getName() + ", ";
		}
		session.createLogger().debug(s);
		
		XMimContour aContour = contours.get(0);
		XMimMutableNDArray data = aContour.getData();
		int[] dimensions = data.getDims();
		XMimNoxelPointI point = session.getPointFactory().createNoxelPointI(
				aContour.getSpace(), 
				new int[aContour.getDims().length]);
		
		double num = 0;
		double dom = 0;
		
		for(int i=0; i<contours.size(); i++) {
			XMimContour contour = contours.get(i);
			for(int j=i+1; j<contours.size(); j++) {
				XMimContour other = contours.get(j);
				
				session.createLogger().debug("processing: " + contour.getInfo().getName() + other.getInfo().getName());
				
				int numVox = 0;
				int domVox = 0;
				
				for(int z=0; z<dimensions[2]; z++) {
					point.setCoord(2, z);
					for(int y=0; y<dimensions[1]; y++) {
						point.setCoord(1, y);
						for(int x=0; x<dimensions[0]; x++) {
							point.setCoord(0, x);
							
							boolean c = contour.getData().getBooleanValue(point);
							boolean o = other.getData().getBooleanValue(point);
							if(c && o) {
								numVox++;
							}
							if(c || o) {
								domVox++;
							}
						}
					}
				}
				
				//we dont need to account for voxel size, since that cancels out
				//assumption: contours always have the same voxel size
				num += numVox;
				dom += domVox;
			}
		}
		
		return num/dom;
	}
	
}
