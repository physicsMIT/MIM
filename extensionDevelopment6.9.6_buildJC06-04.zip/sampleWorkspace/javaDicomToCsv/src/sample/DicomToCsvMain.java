package sample;

import java.awt.Component;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimDicomInfo;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimImageInfo;

/**
 * This extension reads a couple of the DICOM tags for a series and then writes the data to a CSV file.
 * It asks you for the location of the CSV file to save, and if the file already exists, it appends this
 * series as an additional row in the file.
 */
public class DicomToCsvMain {
	@XMimEntryPoint(
			name="Convert DICOM to CSV",
			author="Matt Arpidone",
			description="Reads some of the DICOM tags for a series and appends the data to a CSV file of your choosing",
			category="Misc",
			outputTypes={})
	public Object[] runOnSession(XMimSession session, XMimImage image) {
		Component parentWindow = session.getAppInstance().getMainWindow();
		
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select a destination for the CSV file");
		chooser.setFileFilter(new FileFilter() {
			@Override
			public boolean accept(File f) {
				return f.getName().toLowerCase().endsWith(".csv");
			}
			@Override
			public String getDescription() {
				return "CSV files";
			}
		});
		int result = chooser.showSaveDialog(parentWindow);
		
		if (result == JFileChooser.APPROVE_OPTION) {
			try {
				File csvFile = chooser.getSelectedFile();
				if (!csvFile.getName().toLowerCase().endsWith(".csv")) {
					csvFile = new File(csvFile.getParent(), csvFile.getName() + ".csv");
				}
				boolean fileAlreadyExists = csvFile.exists();
				FileOutputStream fileOutput = new FileOutputStream(csvFile, true);
				
				try {
					PrintWriter writer = new PrintWriter(fileOutput);
					
					try {
						// If the file didn't already exist, write the column headers first before we append a new row
						if (!fileAlreadyExists) {
							writer.println("Patient Name,Age,Series Date,Modality,Series Description");
						}
						
						XMimImageInfo info = null;
						
						try {
							info = image.getInfo();
						} catch (NullPointerException ex) {
							// A bug with dynamic series causes getInfo to throw a NullPointerException rather than return null
						}
						
						if (info == null) {
							// if info is null it's probably because the image is dynamic and we need to slice off a dimension
							info = image.slice(0).getInfo();
						}
						XMimDicomInfo dicom = info.getDicomInfo();
						
						writer.print(replaceCommas(String.valueOf(dicom.getValueByName("PatientName"))));
						writer.append(',').print(replaceCommas(String.valueOf(dicom.getValueByName("PatientAge"))));
						writer.append(',').print(replaceCommas(dateString((Date)dicom.getValueByName("SeriesDate"))));
						writer.append(',').print(replaceCommas(String.valueOf(dicom.getValueByName("Modality"))));
						writer.append(',').print(replaceCommas(String.valueOf(dicom.getValueByName("SeriesDescription"))));
						writer.println();
					} finally {
						writer.close();
					}
				} finally {
					fileOutput.close();
				}
			} catch (IOException ex) {
				session.createLogger().error("Error in DICOM to CSV extension...", ex);
				JOptionPane.showMessageDialog(parentWindow, "Can't write to the CSV file!  " + ex);
			} catch (Throwable t) {
				session.createLogger().error("Error in DICOM to CSV extension", t);
				JOptionPane.showMessageDialog(parentWindow, "An unexpected error occurred: " + t);
			}
		}
		
		return null;
	}
	
	/**
	 * Can't have commas in the values written to a CSV file since comma is the separator, so we replace them with a period instead.
	 * 
	 * Alternatively, we could prepend all commas with an escape character like '\' if we knew that whoever was reading was smart enough
	 * to handle the escapes.  A lot of CSV readers aren't this smart, so I didn't do this.
	 */
	private static String replaceCommas(String s) {
		return s.replace(',', '.');
	}
	
	/**
	 * This example formats dates in DICOM format.  You could change this if you wanted a different format.
	 */
	private static final DateFormat DICOM_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");
	private static String dateString(Date d) {
		if (d == null) {
			return "null";
		}
		return DICOM_DATE_FORMAT.format(d);
	}
}
