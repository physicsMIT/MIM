function doseScaler()

% MIM sends its data to the base workspace
% so you need to manually retrieve
% any data you want to operate on
bridge = evalin('base','bridge');

targetDose = evalin('base','doseToScale');
targetDoseInfo = evalin('base','doseToScale_info');

scaleFactor = evalin('base','scaleFactor'); 

% Since we are applying a uniform scaling factor to every voxel, we can scale by just changing the rescale
% slope rather than modifying all of the actual voxel intensity values.

targetDoseInfo.setRescaleSlope(targetDoseInfo.getRescaleSlope() * scaleFactor);


% Send the original dose back to MIM, but with a modified info object that has a different rescale slope
bridge.sendDoseToMim('scaledDose', targetDoseInfo);
assignin('base', 'scaledDose', targetDose);

end
