function doseStats()

bridge = evalin('base','bridge');

% Pull in the contour and the dose
contour = evalin('base','targetContour');
contourInfo = evalin('base','targetContour_info');
dose = evalin('base','targetDose');
doseInfo = evalin('base','targetDose_info');

% This finds the transform between the contour and the dose volume and assigns it to the var 'xform' (we must use the original var names here)
% Note: xform will be a 4x4 matrix that represents an affine transform
bridge.getLinker().getTransformMatrix('targetContour','targetDose','xform');

% Construct a 4xN array such that each element is the index of a point within the contour
idxs = find(contour);
[ys,xs,zs] = ind2sub(size(contour),idxs);
padCoord = ones(size(xs));

% Note that we have to pad out the 3 element YXZ array so we have a 4 element vector to be compatible for multiplication with the 4x4 matrix 
conCoords = cat(2,ys,xs,zs,padCoord);
conCoords = transpose(conCoords);

doseCoords = xform*conCoords;
doseCoords = doseCoords(1:3,:);

% Use interp to convent the list of dose-space coordinates to interpolated raw values from the dose volume 
doseVals = interp3(single(dose),doseCoords(2,:),doseCoords(1,:),doseCoords(3,:));

% Convert the raw values to actual Gy (or whatever the dose unit happens to be) values
doseVals = doseVals * doseInfo.getRescaleSlope() + doseInfo.getRescaleIntercept();

% Find the max value and convert its location back to the space of the original contour
[maxDoseVal, maxDoseCoordIdx] = max(doseVals(:))
maxConCoord = [conCoords(1,maxDoseCoordIdx),conCoords(2,maxDoseCoordIdx),conCoords(3,maxDoseCoordIdx)];
rawMaxIdx = sub2ind(size(contour), maxConCoord(1),maxConCoord(2),maxConCoord(3));

% Create the marker contour and send it back to MIM
markerContour = logical(zeros(size(contour)));
markerContour(rawMaxIdx) = logical(1);

newInfo = contourInfo.getMutableCopy();
newInfo.setName(strcat(char(newInfo.getName),' Max Dose: ',num2str(maxDoseVal)));
newInfo.setColor(newInfo.getColor().darker());

assignin('base', 'maxDoseMarker', markerContour);
bridge.sendContourToMim('maxDoseMarker', newInfo);

% Send the max dose value back to MIM as well. This will make the value available to workflows that launch this extension so it can be used for further computations.
assignin('base', 'maxDoseValue', maxDoseVal);

end

