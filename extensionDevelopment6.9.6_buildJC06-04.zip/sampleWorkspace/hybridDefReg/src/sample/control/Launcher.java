package sample.control;

import com.mimvista.external.control.XMimAppInstance;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimFlatArray;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.matlab.XMimMatlabInstance;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableImage;
import com.mimvista.external.series.XMimSeriesView;

/**
 * @author bhorstman
 *
 *	Main entry point for example showing how to import DefReg to Matlab (port from MIM4 extension)
 *
 *	This extension can be used to modify the result of a MIM deformable registration, 
 *	and output a new deformed image
 */
public class Launcher {

	private static final String desc = "Launch a matlab extension, " +
			"passing a Deformable Registration matrix.<br/><br/>" +
			"Modify the matrix in matlab, and then output a new deformed secondary";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Hybrid DefReg",
			author="Benjamin P Horstman",
			category="Matlab Helpers",
			description=desc,
			outputTypes={XMimImage.class})
	public static Object[] runOnSession(
			XMimSession session, 
			XMimImage primary, 
			XMimImage secondary,
			XMimImage deformedSecondary) {
		XMimSeriesView result = process(session, primary, secondary, deformedSecondary);
		
		//Our @XMimEntryPoint says we return one XMimImage object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new Object[] {result};
	}
	
	public static XMimSeriesView process(
			XMimSession session, 
			XMimImage primary, 
			XMimImage secondary,
			XMimImage deformedSecondary) {
		XMimLogger log = session.createLogger();
		if(primary.getRawData().getDimensionCount() < 3 ||
				secondary.getRawData().getDimensionCount() < 3 ||
				deformedSecondary.getRawData().getDimensionCount() < 3) {
			log.error("Insufficient dimensions; requires a volumetric image");
			return null;
		}
		
		int[] warpDimensions = deformedSecondary.getRawData().getDims();
		
		log.info("About to build def matrices. Dims: "+warpDimensions[0]+"x"+warpDimensions[1]+"x"+warpDimensions[2]);
		
		int[][] defReg = calculateDeformationMatrices(
				session,
				secondary,
				deformedSecondary);
		
		log.info("Done building matrices, firing up MATLAB.");
		
		XMimAppInstance ai = session.getAppInstance();
		XMimMatlabInstance matlab = ai.createAndStartMatlabInstance(false);
		
		
		try {
		
			log.info("Sending images to MATLAB...");
			
			sendImageToMatlab(matlab, primary, "primary");
			sendImageToMatlab(matlab, secondary, "secondary");
			sendImageToMatlab(matlab, deformedSecondary, "deformedSecondary");
			
			log.info("Sending warp fields to MATLAB...");
			matlab.setArray(
					"deformationX", 
					defReg[0], 
					new int[] {warpDimensions[0], warpDimensions[1], warpDimensions[2]});
			matlab.setArray(
					"deformationY", 
					defReg[1], 
					new int[] {warpDimensions[0], warpDimensions[1], warpDimensions[2]});
			matlab.setArray(
					"deformationZ", 
					defReg[2], 
					new int[] {warpDimensions[0], warpDimensions[1], warpDimensions[2]});
			
			log.info("Running MATLAB program...");
			matlab.runProgram(ai.getExtensionDirectory().getAbsolutePath(), "defReg");
			
			XMimMutableImage newDeformedSecondary = deformedSecondary.getMutableCopy();
			
			log.info("Pulling result back from MATLAB...");
			XMimFlatArray result = matlab.getArray("newDeformedSecondary");
			copyMatlabArrayToJava(result, newDeformedSecondary);
			
			//XMimSeriesView rv = session.addImageAndReturnView(newDeformedSecondary, "New Deformed Secondary");
			session.addImage(newDeformedSecondary, "New Deformed Secondary");
			
			
			return null;
		} finally {
			//matlab.stopMatlabEngine();
		}
	}

	private static int[][] calculateDeformationMatrices(
			XMimSession session,
			XMimImage secondary, 
			XMimImage deformedSecondary) {
		int[] dimensions = deformedSecondary.getRawData().getDims();
		
		//4D matrix: one dimension for each spatial component of the image, 
		//and then one more for the offset for that voxel
		int[][] ret = new int[3][dimensions[0]*dimensions[1]*dimensions[2]];
		
		
		//XMimLinkController allows us to convert locations between different DICOM spaces,
		//just as localization inside MIM does
		XMimLinkController linker = session.getLinker();
		
		float[] pointArray = new float[3];
		XMimNoxelPointF pointSecondary = secondary.createNoxelPointF();
		XMimNoxelPointF pointDeformed = deformedSecondary.createNoxelPointF();
		
		int i=0;
		for(int z=0; z<dimensions[2]; z++) {
			pointArray[2] = z;
			for(int y=0; y<dimensions[1]; y++) {
				pointArray[1] = y;
				for(int x=0; x<dimensions[0]; x++, i++) {
					pointArray[0] = x;
					
					pointDeformed.set(pointArray);
					
					linker.convertPoint(
							pointDeformed, 
							secondary.getSpace(),
							session.getPointFactory().getNoxelCoordSystem(),
							pointSecondary);
					
					
					ret[0][i] = Math.round(pointSecondary.getCoord(0))+1;
					ret[1][i] = Math.round(pointSecondary.getCoord(1))+1;
					ret[2][i] = Math.round(pointSecondary.getCoord(2))+1;
				}
			}
		}
		return ret;
	}

	private static void copyMatlabArrayToJava(XMimFlatArray array, XMimMutableImage image) {
		XMimMutableNDArray data = image.getRawData();
		int[] dimensions = data.getDims();
		
		short[] rawData = (short[])array.getRawArray();
		
		XMimNoxelPointI point = image.createNoxelPointI();
		int i=0;
		for(int z=0; z<dimensions[2]; z++) {
			point.setCoord(2, z);
			for(int y=0; y<dimensions[1]; y++) {
				point.setCoord(1, y);
				for(int x=0; x<dimensions[0]; x++, i++) {
					point.setCoord(0, x);
					
					data.setValue(point, rawData[i]);
				}
			}
		}
	}

	private static void sendImageToMatlab(
			XMimMatlabInstance matlab,
			XMimImage image,
			String string) {
		XMimNDArray data = image.getRawData();
		int[] dimensions = data.getDims();
		short[] array = new short[dimensions[0]*dimensions[1]*dimensions[2]];
		
		XMimNoxelPointI point = image.createNoxelPointI();
		int i=0;
		for(int z=0; z<dimensions[2]; z++) {
			point.setCoord(2, z);
			for(int y=0; y<dimensions[1]; y++) {
				point.setCoord(1, y);
				for(int x=0; x<dimensions[0]; x++,i++) {
					point.setCoord(0, x);
				
					array[i] = data.getShortValue(point);
				}
			}
		}
		
		matlab.setArray(string, array, dimensions);
	}
	
}
