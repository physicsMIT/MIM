% Modify a deformable registration in Matlab
function defReg()

primary = evalin('base','primary');
secondary = evalin('base','secondary');
deformedSecondary = evalin('base','deformedSecondary');

deformationX = evalin('base','deformationX');
deformationY = evalin('base','deformationY');
deformationZ = evalin('base','deformationZ');

%make desired changes to defReg here

% create the output
newDeformedSecondary = int16(interp3(single(secondary),single(deformationX),single(deformationY),single(deformationZ),'nearest'));

assignin('base', 'newDeformedSecondary', newDeformedSecondary);

end
