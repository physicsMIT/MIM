package sample.control;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableImage;
import com.mimvista.external.series.XMimSeriesView;

/**
 * @author bhorstman
 *
 *	Main entry point for Skeletalectomy sample extension (port from MIM4 extension)
 */
public class Skeletalectomy {

	private static final String desc = "Derives a new 3D volume which consists of only bones.";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Skeletalectomy",
			author="Benjamin P Horstman",
			category="Filters",
			description=desc,
			outputTypes={XMimImage.class})
	public static Object[] runOnSession(XMimSession session, XMimImage image) {
		XMimImage result = process(session, image);
		
		//Once we finish processing the result, add it to the session so it can be displayed
		XMimSeriesView view = session.addImageAndReturnView(result, "Derived: only bone");
		
		//Our @XMimEntryPoint says we return one XMimImage object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new XMimSeriesView[] {view};
	}
	
	public static XMimImage process(XMimSession session, XMimImage image) {
		if(image.getRawData().getDimensionCount() < 3) {
			session.createLogger().error("Insufficient dimensions; requires a volumetric image");
			return null;
		}
		
		//MIMextensions don't allow a volume to be modified in place
		//So, create a mutable copy so we can edit it
		XMimMutableImage mutable = image.getMutableCopy();
		
		//Scaled data contains the data scaled for the units, E.g. HU for CT
		XMimMutableNDArray array = mutable.getScaledData();
		int[] dimensions = array.getDims();
		
		XMimNoxelPointI point = image.createNoxelPointI();
		for(int z=0; z<dimensions[2]; z++) {
			point.setCoord(2, z);
			for(int y=0; y<dimensions[1]; y++) {
				point.setCoord(1, y);
				for(int x=0; x<dimensions[0]; x++) {
					point.setCoord(0, x);
					
					float value = array.getFloatValue(point);
					if(value < 400) {
						array.setValue(point, -1024);	//if a voxel is less than bone, set it to air
					}
				}
			}
		}
		
		return mutable;
	}
	
}
