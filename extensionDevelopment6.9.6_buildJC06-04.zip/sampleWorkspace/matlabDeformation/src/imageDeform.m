function imageDeform()

bridge = evalin('base','bridge');
linker = bridge.getLinker;

% Get the deformation field from the linker.

tic;

warp = linker.getDeformationField('a','b');

disp(['Took ',num2str(toc),' seconds to pull down the deformation field.']);

vol1 = evalin('base','a');
vol2 = evalin('base','b');

info_a = evalin('base','a_info'); 
s_a = info_a.getRescaleSlope();
i_a = info_a.getRescaleIntercept();

info_b = evalin('base','b_info'); 
s_b = info_b.getRescaleSlope();
i_b = info_b.getRescaleIntercept();

% The center of the field corresponds to the center of volume 'a', but the dims are generally different so here
% we resample the warp using interp3 to make it the same dimensions as vol1.

desiredXdim = size(vol1,2);
desiredYdim = size(vol1,1);
desiredZdim = size(vol1,3);

currentXdim = size(warp,2);
currentYdim = size(warp,1);
currentZdim = size(warp,3);

xSampleRate = currentXdim/desiredXdim
ySampleRate = currentYdim/desiredYdim
zSampleRate = currentZdim/desiredZdim

xStartOffset = 0.5+(xSampleRate/2);
yStartOffset = 0.5+(ySampleRate/2);
zStartOffset = 0.5+(zSampleRate/2);

tic;

X = xStartOffset:xSampleRate:currentXdim+0.5;
Y = (yStartOffset:ySampleRate:currentYdim+0.5)';
Z = zStartOffset:zSampleRate:currentZdim+0.5;

disp(['Took ',num2str(toc),' seconds to generate sample vectors.']);

tic;

interpolatedWarp(:,:,:,1) = interp3(single(warp(:,:,:,1)),X,Y,Z);
interpolatedWarp(:,:,:,2) = interp3(single(warp(:,:,:,2)),X,Y,Z);
interpolatedWarp(:,:,:,3) = interp3(single(warp(:,:,:,3)),X,Y,Z);

disp(['Took ',num2str(toc),' seconds to interpolate deformation field.']);

% The dimensions of our new interpolated warp field should now match the dimensions of vol1 
origWarpSize = size(warp)
interpWarpSize = size(interpolatedWarp)
deformedVolSize = size(vol1)

tic;

% Clamp the values in the vector field so we never end up sampling outside of vol2.
interpolatedWarp = max(interpolatedWarp, 1);
interpolatedWarp(:,:,:,1) = min(interpolatedWarp(:,:,:,1), size(vol2,2));
interpolatedWarp(:,:,:,2) = min(interpolatedWarp(:,:,:,2), size(vol2,1));
interpolatedWarp(:,:,:,3) = min(interpolatedWarp(:,:,:,3), size(vol2,3)); 

disp(['Took ',num2str(toc),' seconds to clamp deformation field.']);

tic;

% Create a deformed version of vol2 by sampling into it with the interpolated deformation field.  We can assign the result into vol1
% to save memory since it has the proper dimensions and voxel size.
vol1 = interp3(single(vol2)*s_b+i_b,interpolatedWarp(:,:,:,2),interpolatedWarp(:,:,:,1),interpolatedWarp(:,:,:,3),'linear',0);
vol1 = uint16((vol1-i_a)/s_a);

disp(['Took ',num2str(toc),' seconds to generate the deformed image.']);

% Send the deformed volume back into MIM 
assignin('base', 'myNewVol', vol1);
bridge.sendImageToMim('myNewVol', info_a);

end