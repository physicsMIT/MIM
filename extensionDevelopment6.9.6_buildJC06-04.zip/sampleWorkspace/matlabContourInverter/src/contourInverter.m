function contourInverter()
% Stuart Long
% MIM Software, Inc. 2012

% MIM sends its data to the base workspace
% so you need to manually retrieve
% any data you want to operate on

% The bridge object is always present and is used to send data back to MIM proper
bridge = evalin('base','bridge');

contour = evalin('base','ROI1');
cinfo = evalin('base','ROI1_info');

newContour = ~contour;

newinfo = cinfo.getMutableCopy();
newinfo.setName(strcat(char(cinfo.getName()),' (Inv)'));


% Must move the new contour into the 'base' space in order to send it back to MIM
assignin('base', 'invertedContour', newContour);

% Tell the bridge that we want to send a contour from the base space back to MIM
bridge.sendContourToMim('invertedContour',newinfo);

end