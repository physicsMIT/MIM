function fourDeeMean()
% Andy Lee
% MIM Software, Inc. 2014

% MIM sends its data to the base workspace
% so you need to manually retrieve
% any data you want to operate on

bridge = evalin('base','bridge');
base_info = evalin('base','arr_info'); 
volCount = evalin('base','arr_frame_count');

% Since the frames may have differing rescale slope/intercept, we'll use the highest slope
% and lowest intercept to ensure we can cover the entire range of possible values.

max_slope = 0;
min_intercept = 30000;
new_info = base_info.getMutableCopy();

for i = 1:volCount
	allFrames(i,:,:,:) = evalin('base',strcat('arr_frame_',int2str(i)));
	info = evalin('base',strcat('arr_frame_',int2str(i),'_info'));
	max_slope = max(max_slope, info.getRescaleSlope());
	min_intercept = min(min_intercept, info.getRescaleIntercept());
end

% We'll do all the math in single precision floating point and convert back to 16-bit ints at the end
% to maximize our accuracy.
meanVol = single(squeeze(allFrames(1,:,:,:)));

max_slope
min_intercept

new_info.setRescaleSlope(max_slope);
new_info.setRescaleIntercept(min_intercept);

% Calculate the mean for each voxel
for i = 2:volCount
	info = evalin('base',strcat('arr_frame_',int2str(i),'_info'));
	 
	slope = info.getRescaleSlope();
	intercept = info.getRescaleIntercept();

	% Convert the raw int16 values to 'real' values then convert them back to raw using the
	% rescale parameters of our final image.
	meanVol = meanVol + ((single(squeeze(allFrames(i,:,:,:)))*slope+intercept)-min_intercept)/max_slope;
end

% Do the final division to convert from sum to mean and also convert the values
% back to 16 bit ints.
meanVol = int16(meanVol / volCount);

%send the result back to MIM
assignin('base', 'myNewVol', meanVol);
bridge.sendImageToMim('myNewVol', new_info);

end
