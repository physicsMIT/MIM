function dvhGraph()

% MIM sends its data to the base workspace
% so you need to manually retrieve
% any data you want to operate on
% in the variable assignment dialog, you will have to manually add a DVH variable,
% and then drag the contour you want the dvh of into the dialog.
% the 'dvh' in 'dvh_0_vals' is the name you give this variable.
% the vals and widths are added automatically.
% in most mim-generated DVH, there is only one set of values associated with a variable.  thus the '0'.
% for some loaded DVH from RTDOSE, there may be multiple
vals = evalin('base','dvh_0_vals');

width = evalin('base','dvh_0_widths');

% in mim created DVH's width is almost always uniform per bin.
% However it is possible for other system to make bins with variable widths.
scale = width(1);
max = length(vals)-1;
Xaxis = 0:1:max;
Xaxis = Xaxis*scale;

% this extension uses the plot feature of matlab, which might require the matlab UI,
% rather than just logs, as it is configured by default.
% you can configure MATLAB to run with client and leave the environment open
% by going to extensions.txt in MIM config folder, and switching the headless flag to 0.
plot(Xaxis,vals);

end