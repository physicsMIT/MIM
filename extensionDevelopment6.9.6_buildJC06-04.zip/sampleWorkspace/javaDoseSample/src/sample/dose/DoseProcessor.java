package sample.dose;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.data.XMimRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimImageSpace;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimDose;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableDose;
import com.mimvista.external.series.XMimSeriesView;

public class DoseProcessor {

	private static final String desc = "Scales each value in the dose volume by (rawVolumeValue/meanBodyValue)";

	@XMimEntryPoint(
			name="Dose Processing Sample",
			author="Johnny Appleseed",
			description=desc, 
			website="www.mimsoftware.com",
			outputTypes={XMimDose.class},
			icon="scale_dose_icon.png",
			category="Dose", 
			institution="MIM Software", 
			version="1.1")
	public Object[] runOnSession(XMimSession session, XMimDose doseToProcess) {
		DoseProcessor dp = new DoseProcessor(session, doseToProcess);
		XMimMutableDose newDose = dp.processDose();

		session.addDose(newDose);

		return new Object[]{newDose};
	}

	XMimSession sess;
	
	XMimDose originalDose;
	XMimMutableDose newDose;
	
	XMimContour bodyContour;
	
	float meanBodyValue;
	
	float newDoseMin = Float.POSITIVE_INFINITY;
	float newDoseMax = Float.NEGATIVE_INFINITY;
	
	public DoseProcessor(XMimSession sess, XMimDose dose) {
		this.sess = sess;
		this.originalDose = dose;
	}
	
	private void findMaxOwnerValue() {
		XMimLinkController linker = sess.getLinker();
		XMimImage doseOwner = originalDose.getOwner();
		XMimNDArray rawOwnerVals = doseOwner.getRawData();
		
		long voxCount = 0;
		long tally = 0;
		
		XMimMutableNDArray conData = bodyContour.getData();
		XMimNoxelPointI ownerPos = doseOwner.createNoxelPointI();
		
		XMimNoxelPointI contourLoc = sess.getPointFactory().createNoxelPointI(bodyContour.getSpace(), new int[]{0,0,0});
		
		XMimNoxelPointF tmp = sess.getPointFactory().createNoxelPoint(bodyContour.getSpace(), new float[3]);
		XMimImageSpace ownerSpace = doseOwner.getSpace();
		
		for (XMimRLEIterator lineIter : conData.getRleIterable()) {
			int start = -1;
			
			while (lineIter.hasNext()) {
				lineIter.advanceToNextNewValue(contourLoc);
				
				int end = -1;
				if (lineIter.getBoolean()) {
					start = contourLoc.getCoord(0);
					if (!lineIter.hasNext()) {
						end = lineIter.getCurrentLine().getDims()[0];
					}
				} else {
					end = contourLoc.getCoord(0);
				}
				
				if (start != -1 && end != -1) {
					for(int x=start; x<end; x++) {
						contourLoc.setCoord(0, x);
						contourLoc.toVoxelCenter(tmp);
						linker.toRawNoxel(tmp, ownerSpace, tmp);
						tmp.toRawDataLocation(ownerPos);
						short val = rawOwnerVals.getShortValue(ownerPos);
						tally += val;
						voxCount++;
					}
					start = -1;
				}
			}
		}
		
		meanBodyValue = (float)tally/voxCount;
		System.out.println("Raw mean body value: "+meanBodyValue);
	}
	
	private void determineNewScaledDoseMinMax() {
		scaleDoseVoxels(true);
	}
	
	private void scaleDoseVoxels(boolean dryRun) {
		XMimLinkController linker = sess.getLinker();
		
		XMimImage doseOwner = originalDose.getOwner();
		XMimNDArray rawOwnerVals = doseOwner.getRawData();
		
		XMimNDArray doseData = originalDose.getScaledData();
		XMimMutableNDArray newDoseData = newDose.getScaledData();
		int[] doseDims = doseData.getDims();
		XMimNoxelPointI dosePos = originalDose.createNoxelPointI();
		XMimNoxelPointF doseTmp = originalDose.createNoxelPointF();
		
		XMimNoxelPointF ownerPos = doseOwner.createNoxelPointF();
		XMimNoxelPointI ownerPosI = doseOwner.createNoxelPointI();
		XMimImageSpace ownerSpace = doseOwner.getSpace();
		
		for (int z=0; z<doseDims[2]; z++) {
			dosePos.setCoord(2, z);
			for (int y=0; y<doseDims[1]; y++) {
				dosePos.setCoord(1, y);
				for (int x=0; x<doseDims[0]; x++) {
					dosePos.setCoord(0, x);
					
					dosePos.toVoxelCenter(doseTmp);
					linker.toRawNoxel(doseTmp, ownerSpace, ownerPos);
					
					float doseVal = doseData.getFloatValue(dosePos);
					ownerPos.toRawDataLocation(ownerPosI);
					short ownerVal = rawOwnerVals.getShortValue(ownerPosI);
					
					float scaleFactor = (float)ownerVal/meanBodyValue;
					
					float newDoseVal = doseVal*scaleFactor;
					if (dryRun) {
						if (newDoseVal > newDoseMax) newDoseMax = newDoseVal;
						if (newDoseVal < newDoseMin) newDoseMin = newDoseVal;
					} else {
						newDoseData.setValue(dosePos, newDoseVal);
					}
				}
			}
		}
	}
	
	public XMimMutableDose processDose() {
		XMimLogger log = sess.createLogger();
		XMimSeriesView view = null;
		for (XMimSeriesView sv : sess.getAllViews()) {
			//Can't use "==" here because there may be multiple instances of XMimImage that actually represent the same series
			if (sv.getImage().equals(originalDose.getOwner())) {
				view = sv;
				break;
			}
		}
		if (view == null) {
			log.error("Cannot find series view that is currently displaying the dose's owner, failing.");
			return null;
		}
		
		
		XMimImage doseOwner = originalDose.getOwner();
		XMimNDArray rawOwnerVals = doseOwner.getRawData();
		
		if (rawOwnerVals.getDimensionCount() != 3) {
			log.error("Can't handle non-3D dose owners.");
			return null;
		}
		
		newDose = originalDose.getMutableCopy();
		
		bodyContour = sess.getCommandFactory().makeContourBodyCommand(view).execute();
		findMaxOwnerValue();
		determineNewScaledDoseMinMax();
		
		float newIntercept = newDoseMin;
		float newScale = (newDoseMax-newIntercept)/(Short.MAX_VALUE*.8f);
		
		
		newDose.getInfo().setRescaleIntercept(newIntercept);
		newDose.getInfo().setRescaleSlope(newScale);
		
		scaleDoseVoxels(false);
		
		return newDose;
	}
	
}
