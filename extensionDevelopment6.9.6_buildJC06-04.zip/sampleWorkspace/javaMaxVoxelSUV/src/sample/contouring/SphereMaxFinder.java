package sample.contouring;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.series.XMimImage;

/**
 *	Find the minimum and maximum voxels from an image, constrained by a spherical contour
 */
public class SphereMaxFinder {

	private XMimNoxelPointF minVolLocation;
	private XMimNoxelPointF maxVolLocation;
	
	private float min = Float.POSITIVE_INFINITY;
	private float max = Float.NEGATIVE_INFINITY;
	
	private XMimContour con;
	private int[] sphereRadiusVox;
	private XMimNoxelPointF center;
	
	public SphereMaxFinder(XMimContour tgt, float sphereDiameterMM, XMimNoxelPointF center) {
		this.con = tgt;
		
		//Get sphere radius in sub-voxels
		int[] sphereRadiusNox = new int[3];
		float[] noxSize = tgt.getNoxelSizeInMm();
		for(int i = 0; i < sphereRadiusNox.length; i++){
			sphereRadiusNox[i] = Math.round(sphereDiameterMM / (2 * noxSize[i]));
		}
		
		//Get sphere radius in voxels
		int[] mults = tgt.getMultiplier();
		sphereRadiusVox = new int[3];
		for(int i = 0; i < sphereRadiusVox.length; i++){
			sphereRadiusVox[i] = (sphereRadiusNox[i] / mults[i]) + 1;
		}
		this.center = center.clone();
		
		findMinMax();
	}
	
	private void findMinMax() {
		findMinMax(0, con.getMimImage().getSpace().createNoxelPoint());
	}
	
	private void findMinMax(int dim, XMimNoxelPointF imageVoxelCenter) {
		XMimMutableNDArray data = con.getData();
		
		int[] dims = con.getMimImage().getSpace().getDataDims();
		XMimNoxelPointF point = con.getSpace().createNoxelPoint();
		
		int[] multiplier = con.getMultiplier();
		
		//Set minimum to the beginning of the cube surrounding the sphere, or 0
		int xMin = Math.max(0, Math.round(center.getCoord(0) - sphereRadiusVox[0]) - 1);
		int yMin = Math.max(0, Math.round(center.getCoord(1) - sphereRadiusVox[1]) - 1);
		int zMin = Math.max(0, Math.round(center.getCoord(2) - sphereRadiusVox[2]) - 1);
		
		//Set maximum to the end of the cube surrounding the sphere or the end of the image.
		int xMax = Math.min(dims[0], Math.round(center.getCoord(0) + sphereRadiusVox[0]) + 1);
		int yMax = Math.min(dims[1], Math.round(center.getCoord(1) + sphereRadiusVox[1]) + 1);
		int zMax = Math.min(dims[2], Math.round(center.getCoord(2) + sphereRadiusVox[2]) + 1);
		
		for(int x = xMin; x < xMax; x++){
			for(int y = yMin; y < yMax; y++){
				for(int z = zMin; z < zMax; z++){
					imageVoxelCenter.set(new float[]{0.5f + x, 0.5f + y, 0.5f + z});
					point.setCoord(0, imageVoxelCenter.getCoord(0) * multiplier[0]);
					point.setCoord(1, imageVoxelCenter.getCoord(1) * multiplier[1]);
					point.setCoord(2, imageVoxelCenter.getCoord(2) * multiplier[2]);
					
					boolean isInContour = data.getBooleanValue(point.toRawDataLocation());
					if(isInContour){
						//Clone so the min/max location don't continue update with every loop.
						XMimNoxelPointF workingPoint = imageVoxelCenter.clone();
						
						XMimImage img = con.getMimImage();
						float imgValue = img.getScaledData().getFloatValue(workingPoint.toRawDataLocation());
						
						if (imgValue < min) {
							min = imgValue;
							minVolLocation = workingPoint;
						}else if(imgValue == min && getDistanceFromCenter(workingPoint) < getDistanceFromCenter(minVolLocation)){
							//Choose point closest to center of the sphere.
							minVolLocation = workingPoint;
						}
						if (imgValue > max) {
							max = imgValue;
							maxVolLocation = workingPoint;
						}else if(imgValue == max && getDistanceFromCenter(workingPoint) < getDistanceFromCenter(maxVolLocation)){
							//Choose point closest to center of the sphere.
							maxVolLocation = workingPoint;
						}
					}
				}
			}
		}
	}

	/**
	 * Returns the point's distance (in voxels) from the center of the sphere. If the point is not in the same image space
	 * as the center point then results will not make sense.
	 * @param point
	 * @return
	 */
	private double getDistanceFromCenter(XMimNoxelPointF point) {
		double currentDifX = point.getCoord(0) - center.getCoord(0);
		double currentDifY = point.getCoord(1) - center.getCoord(1);
		double currentDifZ = point.getCoord(2) - center.getCoord(2);
		double currentDistance = Math.sqrt(Math.pow(currentDifX, 2) + Math.pow(currentDifY, 2) + Math.pow(currentDifZ, 2));
		return currentDistance;
	}

	public float getMax() {
		return max;
	}
	public float getMin() {
		return min;
	}
	
	/**
	 * Returns a point, corresponding to a voxel center inside the sphere, that has the highest SUV value.
	 * In case of a tie for max value, the point closest to the center is used.
	 * @return
	 */
	public XMimNoxelPointF getMaxLocation() {
		return maxVolLocation;
	}
	/**
	 * Returns a point, corresponding to a voxel center inside the sphere, that has the lowest SUV value.
	 * In case of a tie for min value, the point closest to the center is used.
	 * @return
	 */
	public XMimNoxelPointF getMinLocation() {
		return minVolLocation;
	}
}
