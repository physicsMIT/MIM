package sample.contouring;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;

public class ContourDrawer {

	public static void drawSphere(XMimSession session, XMimContour contour, XMimNoxelPointF crosshairPoint, float diameterInMm) {
		XMimNoxelPointF center = session.getLinker().toRawNoxel(crosshairPoint.clone(), contour.getSpace());
		
		float[] noxSize = contour.getSpace().getNoxSize();
    	float rad = diameterInMm/2;
    	
    	int zVoxRadius = (int)Math.ceil(rad/noxSize[2]);
    	
    	XMimNoxelPointI drawCursor = contour.getMimImage().createNoxelPointI();
    	
    	float centerZ = center.getCoord(2);
    	for (short dZ = 0; dZ <= zVoxRadius; dZ++) {
			int zVoxLoc = Math.round(dZ+centerZ);
			float metricZOffset = (zVoxLoc-centerZ)*noxSize[2];
			float diffy = rad*rad - metricZOffset * metricZOffset;
			
			drawCursor.setCoord(2, zVoxLoc);
			
			if (diffy > 0) {
				float circleRadiusForThisZ = (float) (Math.sqrt(diffy));
				drawCircle(contour, center, circleRadiusForThisZ*2, drawCursor);
			}

			zVoxLoc = Math.round(-dZ+centerZ);
			metricZOffset = (zVoxLoc-centerZ)*noxSize[2];
			diffy = rad * rad - metricZOffset * metricZOffset;
			
			drawCursor.setCoord(2, zVoxLoc);
			
			if (diffy > 0) {
				float circleRadiusForThisZ = (float) (Math.sqrt(diffy));
				drawCircle(contour, center, circleRadiusForThisZ*2, drawCursor);
			}
		}
	}
	
	/**
	 * Draws a one 1x1x1 voxel contour around the input point.
	 */
	public static void drawContourAroundPoint(XMimContour toDraw, XMimContour sphere, XMimNoxelPointF point){
		XMimNoxelPointI scaledPoint = toDraw.getSpace().createNoxelPoint().toRawDataLocation();
		int[] pointsPerVox = toDraw.getMultiplier();
		float[] scaledCoords = getScaledCoords(toDraw, point);
		for(int i = 0; i < scaledCoords.length; i++){
			scaledCoords[i] = scaledCoords[i] - pointsPerVox[i]/2f;
		}
		
		int[] dims = toDraw.getDims();
		int[] voxCoords = new int[scaledCoords.length];
		for(int i = 0; i < scaledCoords.length; i++){
			voxCoords[i] = Math.round(scaledCoords[i]);
			if(voxCoords[i] < 0){
				voxCoords[i] = 0;
			}else if(voxCoords[i] > dims[i]){
				voxCoords[i] = dims[i];
			}
		}
		scaledPoint.set(voxCoords);
		
		for(int z = 0; z < pointsPerVox[2]; z++){
			for(int y = 0; y < pointsPerVox[1]; y++){
				scaledPoint.setCoord(1, voxCoords[1] + y);
				scaledPoint.setCoord(2, voxCoords[2] + z);
				toDraw.getData().setRange(scaledPoint, true, pointsPerVox[0]);
			}
		}
	}
    
	/**
	 * Gets the coordinates of the point in the contour image space. If the point is already in the contour space
	 * then the results may be invalid.
	 * @param contour
	 * @param point
	 * @return
	 */
    private static float[] getScaledCoords(XMimContour contour, XMimNoxelPointF point) {
		int[] scaleFactor = contour.getMultiplier();
		float[] coords = point.toArray();
		for(int i = 0; i < scaleFactor.length; i++){
			coords[i] = coords[i] * scaleFactor[i];
		}
		return coords;
	}

	private static void drawCircle(XMimContour contour, XMimNoxelPointF center, float diameterInMm, XMimNoxelPointI drawCursor) {
		float[] noxSize = contour.getSpace().getNoxSize();
    	float rad = diameterInMm/2;
    	
    	int yVoxRadius = (int)Math.ceil(rad/noxSize[1]);
    	
    	float centerY = center.getCoord(1);
    	for (short dY = 0; dY <= yVoxRadius; dY++) {
			int yVoxLoc = Math.round(dY+centerY);
			float metricYOffset = (yVoxLoc-centerY)*noxSize[1];
			
			drawCursor.setCoord(1, yVoxLoc);
			float metricCircleRadiusForThisY = (float) Math.sqrt(rad * rad - metricYOffset * metricYOffset);
			
			float voxCircleRadiusForThisY = Math.round(metricCircleRadiusForThisY/noxSize[0]);
			
			drawCursor.setCoord(0, Math.round(center.getCoord(0)-voxCircleRadiusForThisY));
			
			contour.getData().setRange(drawCursor, true, Math.round(voxCircleRadiusForThisY*2));
			
			yVoxLoc = Math.round(-dY+centerY);
			drawCursor.setCoord(1, yVoxLoc);
			contour.getData().setRange(drawCursor, true, Math.round(voxCircleRadiusForThisY*2));
		}
    }
	
}
