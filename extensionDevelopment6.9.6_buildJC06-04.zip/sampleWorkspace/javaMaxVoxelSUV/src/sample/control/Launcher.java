package sample.control;

import sample.contouring.ContourDrawer;
import sample.contouring.SphereMaxFinder;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimSeriesView;

public class Launcher {
	
	private static final String SPHERE_NAME = "SUV Sphere";
	private static final String MAX_VALUE_NAME = "SUV Sphere Max Value";
	private static final String desc = "Draws a spherical contour around the crosshair point, then draws contour around the max value voxel center inside the sphere.";
	
	@XMimEntryPoint(
			name="Max SUV Voxel",
			author="David Bauer",
			category="Contouring",
			description=desc,
			outputTypes={})
	public static Object[] runOnSession(XMimSession session, XMimImage image) {
		XMimSeriesView view = getView(session, image);
		XMimNoxelPointF crosshairPoint = view.getCrosshairLocation();
		
		float sphereDiameter = 15;
		XMimContour sphereContour = image.createNewContour(getSafeName(image, SPHERE_NAME));
		ContourDrawer.drawSphere(session, sphereContour, crosshairPoint, sphereDiameter);
		
		SphereMaxFinder finder = new SphereMaxFinder(sphereContour, sphereDiameter, crosshairPoint);
		XMimNoxelPointF maxPoint = finder.getMaxLocation();
		XMimContour peakContour = image.createNewContour(getSafeName(image, MAX_VALUE_NAME));
		ContourDrawer.drawContourAroundPoint(peakContour, sphereContour, maxPoint);
		
		return new Object[] {};
	}
	
	private static String getSafeName(XMimImage image, String name) {
		StringBuilder names = new StringBuilder();
		for(XMimContour contour : image.getContours()){
			names.append(contour.getInfo().getName());
		}
		String toReturn = name;
		int counter = 1;
		while(names.indexOf(toReturn) != -1){
			toReturn = name + "(" + counter + ")";
			counter++;
		}
		
		return toReturn;
	}

	private static XMimSeriesView getView(XMimSession session, XMimImage image){
		for(XMimSeriesView view : session.getAllViews()){
			if(view.getImage().equals(image)){
				return view;
			}
		}
		return null;
	}
	
}
