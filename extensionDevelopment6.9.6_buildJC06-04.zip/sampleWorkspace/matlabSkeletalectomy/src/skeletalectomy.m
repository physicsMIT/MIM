function skeletalectomy()
% Stuart Long
% MIM Software, Inc. 2012

% MIM sends its data to the base workspace
% so you need to manually retrieve
% any data you want to operate on

bridge = evalin('base','bridge');

vol = evalin('base','targetSeries');
info = evalin('base','targetSeries_info'); 
dinfo = info.getDicomInfo();

% You can retrieve DICOM info using hexadecimal strings (e.g. (0008,0060) is the DICOM tag for Modality)
modality = dinfo.getValue('00080060')

% You can also get tag values by name
unit = dinfo.getValueByName('Units')

% You must use these special methods to get the rescale slope and intercept.  Since MIM sometimes rescales
% data as part of the load process (primarily happens when the raw data is 16-bit unsigned and we need to convert
% to 16-bit signed since java doesn't support unsigned primitives), using the rescale slope/intercept from the DICOM
% will produce incorrect results.
slope = info.getRescaleSlope()
intercept = info.getRescaleIntercept()
if isempty(slope)
	slope = 1;
elseif ischar(slope)
	slope = single(str2double(slope));
end
if isempty(intercept)
	intercept = 0;
elseif ischar(intercept)
	intercept = single(str2double(intercept));
end

%our cutoff threshold for not-bone
minVal = single(400)

%zero everything below bone
vol(single(vol(:))*slope+intercept<minVal)=0;

%send the result back to MIM
assignin('base', 'boneOnlySeries', vol);
bridge.sendImageToMim('boneOnlySeries', info);

end
