function sphereMaker()
% Andy Lee
% MIM Software, Inc. 2014

% Draws a 10 mm radius sphere (centered at the center of the provided image) into the provided ROI.

bridge = evalin('base','bridge');

vol = evalin('base','image');
vol_info = evalin('base','image_info');

% We need a template contour in order to create a new contour (a copy of an existing contour info object is required to create a new contour)

roi = evalin('base','templateContour');
roi_info = evalin('base','templateContour_info');

radiusInMm = evalin('base','radiusInMm');

% This finds the transform between the contour and the image and assigns it to the var 'xform' (we must use the original var names here)
% Note: xform will be a 4x4 matrix that represents an affine transform
bridge.getLinker().getTransformMatrix('image','templateContour','xform');

xDimImg = size(vol,1);
yDimImg = size(vol,2);
zDimImg = size(vol,3);

xDimRoi = size(roi,1);
yDimRoi = size(roi,2);
zDimRoi = size(roi,3);

% The dimensions of each pixel/voxel of the image in millimeters
imgNox = vol_info.getNoxelSizeInMm();
% We pad all the 3 element arrays out to 4 so they can be easily pushed through our 4x4 affine xform
imgNox(4) = 1

sphereBoxUpperLeftInImgSpace = [xDimImg/2-radiusInMm/imgNox(1), yDimImg/2-radiusInMm/imgNox(2), zDimImg/2-radiusInMm/imgNox(3), 1]
sphereBoxLowerRightInImgSpace = [xDimImg/2+radiusInMm/imgNox(1), yDimImg/2+radiusInMm/imgNox(2), zDimImg/2+radiusInMm/imgNox(3), 1]

sphereBoxUpperLeftInImgSpace = transpose(sphereBoxUpperLeftInImgSpace);
sphereBoxLowerRightInImgSpace = transpose(sphereBoxLowerRightInImgSpace);

% In order to determine the bounding box of the sphere in contour noxel space, we define the corners in image space and convert
% them over using the affine xform.  Note that this will only work if the contour is native to the provided image.  Otherwise,
% there could be a rotational component in the matrix that would violate the assumptions we're making with this math.

sphereDimsInImgNoxSpace = sphereBoxLowerRightInImgSpace-sphereBoxUpperLeftInImgSpace

sphereBoxUpperLeftInRoiSpace = xform*sphereBoxUpperLeftInImgSpace
sphereBoxLowerRightInRoiSpace = xform*sphereBoxLowerRightInImgSpace

sphereDimsInRoiNoxSpace = sphereBoxLowerRightInRoiSpace - sphereBoxUpperLeftInRoiSpace
sphereRadiusInRoiNoxSpace = sphereDimsInRoiNoxSpace/2

noxScaleFactors = sphereDimsInImgNoxSpace./sphereDimsInRoiNoxSpace

roiNox = noxScaleFactors.*imgNox

% Loop through the bounding box and turn on each noxel that's within the sphere
for dz = int32(-sphereRadiusInRoiNoxSpace(3)):int32(sphereRadiusInRoiNoxSpace(3))
	for dy = int32(-sphereRadiusInRoiNoxSpace(2)):int32(sphereRadiusInRoiNoxSpace(2))
		for dx = int32(-sphereRadiusInRoiNoxSpace(1)):int32(sphereRadiusInRoiNoxSpace(1))
			if ( sqrt( (single(dx)*roiNox(1))^2+(single(dy)*roiNox(2))^2+(single(dz)*roiNox(3))^2 ) <= radiusInMm)
				% If we're within 10 mm of the center of the sphere, turn the noxel on
				roi(xDimRoi/2+dx,yDimRoi/2+dy,zDimRoi/2+dz) = true;
			end
		end
	end
end

sphere_info = roi_info.getMutableCopy();
sphere_info.setName([num2str(radiusInMm), ' mm Sphere']);

% Must move the new contour into the 'base' space in order to send it back to MIM
assignin('base', 'sphereContour', roi);

% Tell the bridge that we want to send a contour from the base space back to MIM
bridge.sendContourToMim('sphereContour', sphere_info);

end
