package sample.control;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableImage;
import com.mimvista.external.series.XMimSeriesView;

/**
 * 	This extension shows how to use javac at runtime to dynamically compile code based on user input
 * 
 * @author bhorstman
 */
public class Launcher {

	private static final String desc = "Derives a new 3D volume where the voxels are calculated based on a user defined voxelwise formula";

	/**
	 *	This is the interface we'll assume the compiled code implements
	 */
	public static interface MyFunction {
		public double f(double a, double b);
	}

	/**
	 * 	We'll output this string, with the user's function in %s
	 * 	Then, we'll compile it with javac, 
	 * 	load it into memory, create an instance, 
	 * 	and use it to do our calculation
	 */
	private static String myFuncCode = "" +
			"public class MyFunctionImpl implements sample.control.Launcher.MyFunction {" +
			"	public double f(double a, double b) {" +
			"		return ~!~;" +
			"	}" +
			"}";
	
	@XMimEntryPoint(
			name="Voxelwise Math w/ Formula as Input",
			author="Andy Lee",
			category="Mathematical",
			description=desc,
			version="1.0",
			outputTypes={XMimSeriesView.class})
	public static Object[] runWithFormulaInput(XMimSession session, XMimImage first, XMimImage second, String formula) {
		File extDir = session.getAppInstance().getExtensionDirectory();
		
		String code = myFuncCode.replaceAll(Pattern.quote("~!~"), formula);
		
		session.createLogger().debug("writing code: " + code);
		
		File f = writeJavaCode(extDir, code);
		
		session.createLogger().debug("loading class");
		Class<MyFunction> c = loadClass(extDir, f);
		
		session.createLogger().debug("instantiating class");
		MyFunction function = makeInstance(c);

		session.createLogger().debug("beginning processing");
		XMimImage result = process(session, first, second, function);
		
		//Once we finish processing the result, add it to the session so it can be displayed
		XMimSeriesView view = session.addImageAndReturnView(result, "Derived: " + formula);
		
		//Our @XMimEntryPoint says we return one XMimSeriesView object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new Object[] {view};
	}
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Voxelwise Math",
			author="Benjamin P Horstman",
			category="Mathematical",
			description=desc,
			version="2.0",
			outputTypes={XMimSeriesView.class})
	public static Object[] runOnSession(XMimSession session, XMimImage first, XMimImage second) {
		String stringFunction = queryForUserInput();
		
		return runWithFormulaInput(session, first, second, stringFunction);
	}
	
	private static MyFunction makeInstance(Class<MyFunction> c) {
		try {
			//we can't do c.newInstance() because that sets private methods accessible
			return (MyFunction) c.getConstructors()[0].newInstance();
		} catch (Throwable t) {
			throw new RuntimeException(t);
		}
	}

	/**
	 * 	Compile the code with javac, then load the class
	 * 
	 * 	This function operates under the assumption the extension directory is on the extension classloader (true in MIM 6.0)
	 * 
	 * @param extDir
	 * @param f
	 * @return
	 */
	private static Class<MyFunction> loadClass(File extDir, File f) {
		//we make the assumption that javac is on our path
		List<String> args = new ArrayList<String>();
		args.add("javac");
		args.add("-cp");
		args.add("ext.jar");
		args.add("MyFunctionImpl.java");
		try {
			ProcessBuilder pb = new ProcessBuilder(args);
			pb.directory(extDir);
			pb.redirectErrorStream();
			Process process = pb.start();
			
			int wf = process.waitFor();
			
			if(wf != 0) {
				InputStream is = process.getInputStream();
				
				BufferedReader br = new BufferedReader(new InputStreamReader(is));
				
				StringBuilder sb = new StringBuilder();
				while(br.ready()) {
					sb.append(br.readLine());
				}
				
				throw new RuntimeException("compile failed with: " + sb.toString());
			}
			
			return (Class<MyFunction>) Class.forName("MyFunctionImpl");
		} catch (Throwable t) {
			throw new RuntimeException(t);
		}
	}

	/**
	 * 	Write the java code to a file so we can compile it
	 * 
	 * @param extDir
	 * @param code
	 * @return
	 */
	private static File writeJavaCode(File extDir, String code) {
		File rv = new File(extDir, "MyFunctionImpl.java");
		
		FileWriter writer = null;
		try {
			writer = new FileWriter(rv);
			writer.write(code);
			writer.flush();
			
		} catch (Throwable e) {
			throw new RuntimeException(e);
		} finally {
			try {
				if(writer != null) {
					writer.close();
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		
		return rv;
	}

	private static String queryForUserInput() {
		return JOptionPane.showInputDialog("Enter forumula (use a and b as variables and +-/*):");
	}

	private static void performComputation(XMimSession session, XMimImage first, XMimImage second, MyFunction function, ResultHandler handler) {
		//the linker lets us convert points between any images which have been registered in MIM
		XMimLinkController linker = session.getLinker();
		
		//Scaled data contains the data scaled for the units, E.g. HU for CT
		XMimNDArray firstArray = first.getScaledData();
		XMimNDArray secondArray = second.getScaledData();
		
		//we need some temporary points to reduce allocations when using the linker
		XMimNoxelPointI firstPoint = first.createNoxelPointI();
		XMimNoxelPointF firstPointF = firstPoint.toVoxelCenter();
		XMimNoxelPointI secondPoint = second.createNoxelPointI();
		XMimNoxelPointF secondPointF = secondPoint.toVoxelCenter();
		
		int[] dimensions = firstArray.getDims();
		
		//now we'll step through each voxel in the first image and apply the equation
		for(int z=0; z<dimensions[2]; z++) {
			firstPoint.setCoord(2, z);
			for(int y=0; y<dimensions[1]; y++) {
				firstPoint.setCoord(1, y);
				for(int x=0; x<dimensions[0]; x++) {
					firstPoint.setCoord(0, x);
					firstPoint.toVoxelCenter(firstPointF);
					
					//convert the location firstPointF to the equavalent point in the second image,
					//after respecting any arbitrary transforms
					linker.convertPoint(firstPointF, second.getSpace(), null, secondPointF);
					
					secondPointF.toRawDataLocation(secondPoint);
					
					float out = 0;
					//because of the transform, we could be out of bounds
					if(secondArray.isPointInArray(secondPoint)) {
						//the two scaled values from each image, e.g., in HUs
						float a = firstArray.getFloatValue(firstPoint);
						float b = secondArray.getFloatValue(secondPoint);
						
						out = (float) function.f(a, b);
					}
					
					handler.handleResult(out, firstPoint);
				}
			}
		}
	}
	
	private static interface ResultHandler {
		public void handleResult(float value, XMimNoxelPointI location);
	}
	
	public static XMimImage process(XMimSession session, XMimImage first, XMimImage second, MyFunction function) {
		if(first.getRawData().getDimensionCount() < 3 || second.getRawData().getDimensionCount() < 3) {
			session.createLogger().error("Insufficient dimensions; requires a volumetric image");
			return null;
		}

		long t = System.nanoTime();
		
		//We do a first pass to determine what the min/max of the resulting image will be so we can set
		//an appropriate rescale slope/intercept
		final float[] min = new float[]{Float.MAX_VALUE};
		final float[] max = new float[]{-Float.MAX_VALUE};
		
		performComputation(session, first, second, function, new ResultHandler() {
			@Override
			public void handleResult(float value, XMimNoxelPointI location) {
				if (Float.isNaN(value) || Float.isInfinite(value)) return;
				
				if (value < min[0]) min[0] = value;
				if (value > max[0]) max[0] = value;
			}
		});
		
		
		System.out.println("new min: "+min[0]);
		System.out.println("new max: "+max[0]);
		
		float newIntercept = (float)Math.floor(min[0]);
		if (newIntercept < 1000 && newIntercept > 0) {
			newIntercept = 0;
		}
		
		System.out.println("New intercept: "+newIntercept);
		
		int maxRawRange = Short.MAX_VALUE-10;
		
		float newSlope = 1;
		float rawRange = (max[0]-newIntercept)/newSlope;
		
		System.out.println("Raw range init: "+rawRange);
		
		//Keep the rescale slope a multiple of 10 to prevent ending up with ugly values in the resulting image
		while (maxRawRange > rawRange*10) {
			newSlope /= 10;
			rawRange = (max[0]-newIntercept)/newSlope;
		}
		while (rawRange > maxRawRange) {
			newSlope *= 10;
			rawRange = (max[0]-newIntercept)/newSlope;
		}
		
		System.out.println("New slope: "+newSlope);
		
		
		//MIMextensions don't allow a volume to be modified in place
		//So, create a mutable copy so we can edit it
		XMimMutableImage mutable = first.getMutableCopy();
		mutable.getInfo().setRescaleIntercept(newIntercept);
		mutable.getInfo().setRescaleSlope(newSlope);
		
		final XMimMutableNDArray mutableArray = mutable.getScaledData();
		
		performComputation(session, first, second, function, new ResultHandler() {
			@Override
			public void handleResult(float value, XMimNoxelPointI location) {
				if (Float.isNaN(value) || value == Float.POSITIVE_INFINITY) {
					//Almost certain division by zero, so use the max value
					value = max[0];
				} else if (value == Float.NEGATIVE_INFINITY) {
					value = min[0];
				}
				mutableArray.setValue(location, value);
			}
		});
		
		session.createLogger().info("Extension took (ms) to run: " + (System.nanoTime() - t)/1000/1000);
		
		return mutable;
	}
}
