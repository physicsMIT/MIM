package sample.control;

import javax.swing.JOptionPane;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableImage;
import com.mimvista.external.series.XMimSeriesView;
import com.mimvista.external.series.reslice.XMimVolumeReslicer;
import com.mimvista.external.series.reslice.XMimVolumeReslicerParams;

/**
 * This extension does "slabbing" which is basically reducing the number of slices in an image
 *
 * The default implementation only does bilinear interpolation.
 * So, it will need modifications to do other types such as MIP slabbing or bilinear with area averaging
 */
public class Launcher {

	private static final String desc = "Derives a new 3D volume which may have fewer slices";
	
	private static XMimLogger logger;
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Slabbing",
			author="Benjamin P Horstman",
			category="Filters",
			description=desc,
			outputTypes={XMimImage.class})
	public static Object[] runOnSession(XMimSession session, XMimImage image) {
		logger = session.createLogger();
		
		String string = JOptionPane.showInputDialog("Select number of slices to merge in each direction", 1);
		
		int mergeSlices = 1;
		try {
			mergeSlices = Integer.valueOf(string);
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "The value you entred is not a number...");
		}
		
		XMimImage result = process(session, image, mergeSlices);
		
		//Once we finish processing the result, add it to the session so it can be displayed
		XMimSeriesView ret = session.addImageAndReturnView(result, "Derived: slabbed");
		
		//Our @XMimEntryPoint says we return one XMimImage object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new Object[] {ret};
	}
	
	//Since MIM 6.7, floats/ints can be used as inputs and outputs to extensions, so you no longer have to prompt the
	//user for numerical input values yourself.
	@XMimEntryPoint(
			name="Slabbing (No Prompt)",
			author="Andy Lee",
			category="Filters",
			description=desc,
			outputTypes={XMimImage.class})
	public static Object[] headlessSlab(XMimSession session, XMimImage image, int slabSize) {
		logger = session.createLogger();
		
		XMimImage result = process(session, image, slabSize);
		
		//Once we finish processing the result, add it to the session so it can be displayed
		XMimSeriesView ret = session.addImageAndReturnView(result, "Derived: slabbed");
		
		//Our @XMimEntryPoint says we return one XMimImage object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new Object[] {ret};
	}
	
	public static XMimImage process(XMimSession session, XMimImage image, int slicesToMerge) {
		int[] dimensions = image.getRawData().getDims();
		if(dimensions.length < 3) {
			String string = "Insufficient dimensions; requires a volumetric image";
			session.createLogger().error(string);
			throw new RuntimeException(string);
		}
		if(dimensions.length == 4 && dimensions[3] > 1) {
			String string = "Too many dimensions; doesn't support dynamic images";
			session.createLogger().error(string);
			throw new RuntimeException(string);
		}
		
		//we can use the ReSlicer to derive new DICOM
		XMimVolumeReslicer vr = session.createVolumeReslicer();
		
		//the params allow us to control the newly created volume
		XMimVolumeReslicerParams params = vr.createParamsFrom(image);
		
		int factor = slicesToMerge*2 + 1;
		
		//set the new dimensions based on the number of slices which will be merged
		int[] newDims = params.getDimensions();
		newDims[2] = (int) Math.ceil((double)newDims[2] / factor);	
		if(newDims[2] % 2 != dimensions[2] % 2) {
			//if we change from even to odd (or vice versa),
			//we'll be off by half a slice since MIM aligns
			//based on the center of the image...
			//we want the voxels to line up, so add one more
			newDims[2]++;
		}
		params.setDimensions(newDims);
		
		float[] newVoxel = params.getVoxelSizeMM();
		newVoxel[2] = newVoxel[2] * factor;
		params.setVoxelSizeMM(newVoxel);
		
		//we'll leave the other parameters the same, since we don't want to rotate the image
		XMimMutableImage mutable = vr.derive(params);
		
		//as stated in the comments, we'll only do bilinear by default
		//for other varieties, you would adjust the values in mutable at this point
//		adjustDataBasedOnSlabbingTechnique(image, mutable);
		
		return mutable;
	}

	//here's a default implementation which does MIP
	private static void adjustDataBasedOnSlabbingTechnique(XMimImage image, XMimMutableImage mutable) {
		//Scaled data contains the data scaled for the units, E.g. HU for CT
		//since it's only a linear transform, we can just do the MIP on the raw data
		XMimNDArray oldArray = image.getRawData();
		int[] oldDims = oldArray.getDims();
		float[] oldNoxel = image.getNoxelSizeInMm();
		
		XMimMutableNDArray newArray = mutable.getRawData();
		int[] newDims = newArray.getDims();
		float[] newNoxel = mutable.getNoxelSizeInMm();
		
		int doubleSlicesToMerge = (int) Math.round((double)oldDims[2] / newDims[2]);
		int slicesToMerge = (int) Math.floor(doubleSlicesToMerge/2.0);
		
		//we need a point in each image for reading and writing
		XMimNoxelPointI oldPoint = image.createNoxelPointI();
		XMimNoxelPointI newPoint = mutable.createNoxelPointI();
		
		//clear out the new image, since we're going to calculate our own values
		for(int z=0; z<newDims[2]; z++) {
			newPoint.setCoord(2, z);
			for(int y=0; y<newDims[1]; y++) {
				newPoint.setCoord(1, y);
				for(int x=0; x<newDims[0]; x++) {
					newPoint.setCoord(0, x);
					
					newArray.setValue(newPoint, Short.MIN_VALUE);
				}
			}
		}
		
		//since MIM aligns the center of the volume, we need to offset things
		//slightly so that the default FOR link is correct and the slices line up when fused
		//XXX: tricky math
		int extraSlices = (int) ((newDims[2] * newNoxel[2] - oldDims[2] * oldNoxel[2]) / oldNoxel[2]);
		int extraSlicesTop = extraSlices/2;
		int slicesPer = Math.round(newNoxel[2] / oldNoxel[2]);
		int outOfImageSlicesTop = slicesPer - extraSlicesTop;
		logger.debug("using slicesPer: " + slicesPer);
		logger.debug("using outOfImageSlicesTop: " + outOfImageSlicesTop);
		int offset = (int) (-Math.ceil(slicesPer/2.0) + outOfImageSlicesTop);
		
		logger.debug("using offset: " + offset);
		
		for(int z=0; z<newDims[2]; z++) {
			newPoint.setCoord(2, z);
			
			//for each point in the new image, check all of the nearby slices in the
			//old image and find the maximum
			for(int dz=-slicesToMerge; dz<slicesToMerge+1; dz++) {
				int zInOldVoxels = Math.round(z*newNoxel[2]/oldNoxel[2]);
				int oldZ = zInOldVoxels + dz + offset;
				
				//for off-image points, we clamp to the edge
				oldZ = Math.min(oldZ, oldDims[2]-1);
				oldZ = Math.max(oldZ, 0);
				
				oldPoint.setCoord(2, oldZ);
				
				for(int y=0; y<newDims[1]; y++) {
					oldPoint.setCoord(1, y);
					newPoint.setCoord(1, y);
					for(int x=0; x<newDims[0]; x++) {
						oldPoint.setCoord(0, x);
						newPoint.setCoord(0, x);
						
						//newArray has either Short.MIN_VALUE or the max value seen so far
						short value = newArray.getShortValue(newPoint);
						value = (short) Math.max(value, oldArray.getShortValue(oldPoint));
						newArray.setValue(newPoint, value);
					}
				}
			}
		}
	}

}
