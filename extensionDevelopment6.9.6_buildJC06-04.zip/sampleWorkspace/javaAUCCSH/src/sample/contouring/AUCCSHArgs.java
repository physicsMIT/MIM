package sample.contouring;

import java.io.Serializable;

public class AUCCSHArgs implements Serializable{
	private static final long serialVersionUID = 1L;
	public double minVal;
	public double maxVal;
	public double[] values;
	public double[] frequencies;
	public double[] centers;
	public double totalWidth;
	public double binWidth;
	public double numBuckets = 1000;
	
	private final String SEPARATOR = "&";
	public String contourName;
	
	public AUCCSHArgs(String contName, double min, double max, double[] vals){
		contourName = contName;
		minVal = min;
		maxVal = max;
		totalWidth = Math.abs(0 - maxVal);
		binWidth = totalWidth/numBuckets;
		values = vals;
		
		setCenters();
		setFrequencies();
		argsToPercentage();
	}

	private void setCenters() {
		centers = new double[(int) numBuckets];
		
		double curCenter = 0 + binWidth/2.0;
		
		for(int i = 0; i < centers.length; i++){
			centers[i] = curCenter;
			curCenter += binWidth;
		}		
	}
	
	private void setFrequencies() {
		frequencies = new double[(int) numBuckets];
		for(int i = 0; i<values.length; i++){
			for(int j = 0; j<numBuckets; j++){
				if(values[i] - (centers[j] - binWidth/2) >= 0){
					// We are making a cumulative histogram.
					// Each value can be in multiple buckets
					frequencies[j]++;
				} else {
					// Let's break out of this loop. There are no more buckets this val can fit in. 
					j = (int) numBuckets;
				}
			}
		}
	}
	
	private void argsToPercentage() {
		for(double center : centers){
			center = (center-minVal)/maxVal;
		}
		
		for(double frequency : frequencies){
			frequency = 100*(frequency/frequencies[0]);
		}
		
		binWidth = 100/numBuckets;		
	}
	
	public AUCCSHArgs(String inputString) {
		// This is the constructor used in the AUCCSHPanel class when we 
		// pass our data as a string. Rather than store all of our values,
		// we send the frequency of contained in each bucket to be passed to 
		// the AUCCSHPanel from the main AUCCSH class
		
		
		// The passed string has this form:
		// "name, min, max, bucket0 freq, bucket1 freq,...bucket999 freq"
		
		String[] parsedString = inputString.split(SEPARATOR);
		values = new double[parsedString.length - 3];
		
		frequencies = new double[(int) numBuckets];
		
		this.contourName = parsedString[0];
		this.minVal = Double.parseDouble(parsedString[1]);
		this.maxVal = Double.parseDouble(parsedString[2]);
		
		for (int i = 0; i< numBuckets; i++){
			frequencies[i] = Double.parseDouble(parsedString[i+3]);	
		}
		
	}
	
	public String returnStringArgs(){
		
		String argString = "";
		
		argString = argString + contourName + SEPARATOR;
		argString = argString + minVal + SEPARATOR;
		argString = argString + maxVal + SEPARATOR;
		
		for(int i = 0; i<frequencies.length; i++){
			argString = argString + frequencies[i] + SEPARATOR;
		}
		
		return argString;
	}
}
