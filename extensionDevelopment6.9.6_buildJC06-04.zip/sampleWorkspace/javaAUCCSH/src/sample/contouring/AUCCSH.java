package sample.contouring;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Lists;
import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.data.XMimRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.stats.XMimContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumericContourStat;


public class AUCCSH {
	private static final int numBuckets = 1000;
		
	private static final String aucheteroDesc = "Creates a histogram of AUC-CSH Method";
	private static Map<XMimContour, Process> processes = new HashMap<XMimContour, Process>();
	
	@XMimEntryPoint(
			name="AUC-CSH Hereogeneity Analysis",
			author="James Fitzpatrick",
			category="Statistics",
			institution="MIM Software, inc.",
			version="1.0.0",
			description=aucheteroDesc)
	public static Object[] computeAUCCSHHistogram(XMimSession Session, List<XMimContour> Contours){
		for (XMimContour contour: Contours) {
			AUCCSH.process(Session, contour);
		}
		return new Object[0];
	}
			
	public static void process(XMimSession session, XMimContour Contour) {
		integrateStatistics(session, Contour);
	}

	public static AUCCSHArgs generateArgs(XMimSession session, XMimContour contour){
		ArrayList<Double> values = Lists.newArrayList();
		double minVal = Double.POSITIVE_INFINITY;
		double maxVal = Double.NEGATIVE_INFINITY;
	
		XMimImage image = contour.getMimImage();

		// Set up and resize the PET volume to match the contour resolution 
				
		//links and points for converting between different spaces
		XMimLinkController link = session.getLinker();
		
		final XMimNoxelPointF imageNoxel = image.createNoxelPointF();
		
		//a few extra points, used to reduce memory allocation
		XMimPointF conPoint = link.toRawNoxel(imageNoxel, contour.getSpace());
		XMimNoxelPointF contourNoxelF = conPoint.getCoordSystem().toRawNoxel(conPoint);
		XMimNoxelPointI contourNoxelI = contourNoxelF.toRawDataLocation();
		
		//scaledImgData represents the raw voxels, scaled to the actual units (e.g. HU)
		XMimNDArray scaledImgData = image.getScaledData();
		
		for(XMimRLEIterator lineIter : contour.getData().getRleIterable()){
			// Find the start and end points. 
			int start = -1;
			
			while(lineIter.hasNext()){
				lineIter.advanceToNextNewValue(contourNoxelI);
				
				int end = -1;
				
				if (lineIter.getBoolean()){
					start = contourNoxelI.getCoord(0);
					if(!lineIter.hasNext()){
						end = lineIter.getCurrentLine().getDims()[0];
					}
				}
				else{
					end = contourNoxelI.getCoord(0);					
				}
				
				// Once we have a start and end value of our line
				if(start != -1 && end != -1) {
					for(int i = start; i < end; i++){
						
						contourNoxelI.setCoord(0, i);
						
						//this just changes our integer point into a float one
						contourNoxelI.toVoxelCenter(contourNoxelF);

						//convert the point from the contour space to the image space
						link.toRawNoxel(contourNoxelF, image.getSpace(), imageNoxel);
						
						//acquire the value at this voxel
						double val = scaledImgData.getDoubleValue(imageNoxel.toRawDataLocation());
						values.add(val);
						if(val > maxVal){
							maxVal = val;
						}
						
						if(val < minVal){
							minVal = val;
						}
					}
				}
			}
		}

		double[] valsToSend = new double[values.size()];
		for(int i = 0; i<valsToSend.length; i++){
			valsToSend[i] = values.get(i);
		}
		
		return new AUCCSHArgs(contour.getInfo().getName(), minVal, maxVal, valsToSend);
	}
	
	
	
	public static void launchHistogramProcess(final XMimSession session, XMimContour contour, AUCCSHArgs passedArgs) throws IOException {
		if(processes.containsKey(contour)) {
			processes.get(contour).destroy();
			processes.remove(contour);
		}
		File extDir = session.getAppInstance().getExtensionDirectory();		
		File jreDirectory = session.getAppInstance().getJavaExecutableDirectory();
		
		XMimLogger logger = session.createLogger();
		logger.debug("Directory: " + extDir);
		session.createLogger().debug("JRE Directory: " + jreDirectory);
		
		String os = System.getProperty("os.name").toLowerCase();
		String javaExecutable;
		String sep = "";
		if (os.indexOf("win") != -1) {
			javaExecutable = "java.exe";
			sep = ";";
		} else {
			javaExecutable = "java";
			sep = ":";
		}
		
		String javaExecutablePath = jreDirectory.getCanonicalPath() + "/" + javaExecutable;
		String classPath = 
				extDir.getCanonicalPath() + "/ext.jar" + sep +
				extDir.getCanonicalPath() + "/lib/jcommon-1.0.18.jar"+		sep +	
				extDir.getCanonicalPath() + "/lib/jfreechart-1.0.15.jar";
		String className = "sample.contouring.AUCCSHPanel";
		
		List<String> runCommand = new ArrayList<String>();
				
		runCommand.add(javaExecutablePath);
		runCommand.add("-cp");
		runCommand.add(classPath);
		runCommand.add(className);
		runCommand.add("\"" + passedArgs.returnStringArgs() + "\"");
					
		ProcessBuilder runFile = new ProcessBuilder(runCommand);
		runFile.directory(jreDirectory);
		
		runFile.redirectErrorStream(true);
								
		processes.put(contour, runFile.start());
		
		//Need to make sure we drain the stream of our process
		startStreamPuller(processes.get(contour).getInputStream(), logger);
	}
	
	private static void startStreamPuller(InputStream stream, final XMimLogger logger) {
		final BufferedReader br = new BufferedReader(new InputStreamReader(new BufferedInputStream(stream)));

		Runnable streamPuller = new Runnable() {
			public void run() {
				try {
					logger.debug("Start pulling");
					while (true) {
						String nextLine = br.readLine();
						if (nextLine == null) {
							break;
					}
						logger.info("Histogram Process Stream: " + nextLine);
					}
					logger.debug("Done pulling");
				} catch (Throwable t) {
					logger.error(t.getMessage());
				} finally {
					try {br.close();} catch (IOException e) {}
				}
			}
		};
		new Thread(streamPuller).start();
	}
	
	private static void integrateStatistics(final XMimSession sess, XMimContour cont) {		
		sess.createLogger().info("Adding AUC stat.");
		launchAnalysis(sess,cont);
		cont.registerNewStat(new XMimNumericContourStat() {
			@Override
			public String getStatName() {
				return "Total Area Under Curve";
			}
			@Override
			public XMimContourStatId getStatId() {
				return new XMimContourStatId("AUC-CSH", "MIMEX");
			}
			
			@Override
			public String getAbbreviatedName() {
				return "AUC";
			}
			@Override
			public Number computeResult(XMimContourStatContext context) {				
				AUCCSHArgs passedArgs = AUCCSH.launchAnalysis(sess,context.getContour());
				double sum = 0;
				for(int i = 1; i<numBuckets; i++){
					double absAvg = Math.abs(passedArgs.frequencies[i]/passedArgs.frequencies[0]
														+ passedArgs.frequencies[i-1]/passedArgs.frequencies[0])/2;
					sum += passedArgs.binWidth * absAvg*100;
				}
				
				return sum;
			}
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				return null;
			}
		});
	}
	
	private static AUCCSHArgs launchAnalysis(final XMimSession sess, XMimContour contour) {
		sess.createLogger().info("Computing stat for " + contour.getInfo().getName());
		AUCCSHArgs passedArgs = generateArgs(sess, contour);
		
		//Don't try to show the histogram window if we're running headlessly
		if (!Boolean.getBoolean("java.awt.headless")) {
			try {
				launchHistogramProcess(sess, contour, passedArgs);
			} catch (Throwable e) {
				sess.createLogger().error("io error: ", e);
			}
		}
		return passedArgs;
	}
}
