package sample.contouring;

public class HistogramVal{
	public double value;
	public double width;
	public int frequency;
			
	public HistogramVal(double v, double w){
		this(v,w,0);
	}
	
	
	public HistogramVal(double v, double w, int f){
		value = v;
		width = w;
		frequency = f;
	}
	
	public boolean isValueInRange(double v){
		if(Math.abs(v-value) <= width/2){
			return true;
		} else {
			return false;
		}
	}		
}
