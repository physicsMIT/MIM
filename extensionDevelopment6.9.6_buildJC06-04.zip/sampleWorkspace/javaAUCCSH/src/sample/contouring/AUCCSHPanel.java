package sample.contouring;

import java.awt.BorderLayout;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.xy.StandardXYBarPainter;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.statistics.HistogramDataset;
import org.jfree.data.statistics.HistogramType;


public class AUCCSHPanel extends JFrame {
	
	private static final long serialVersionUID = 1L;
	public HistogramDataset line;
	public HistogramDataset subsection;
	public HistogramVal[] buckets;
	public double[] frequencies;
	
	public double numBuckets = 1000;
	public double binWidth;
	
	
	public ChartPanel chartPanel;
	
	public AUCCSHArgs info;
	
	public String contourName; 
	public double minValue;
	public double maxValue;
	public double maxFrequency;
	public double[] values;
	
	private static JFrame frame;
	
	private String title;
	private static final String X_AXIS_LABEL = "SUV Max (%)";
	private static final String Y_AXIS_LABEL = "Volume (%)";
	
	public static void main(String[] args) throws InterruptedException{
		System.out.println("AUCCSH Panel Launched");
		
		AUCCSHPanel panel = new AUCCSHPanel();
		
		AUCCSHArgs inputArgs = new AUCCSHArgs(args[0]);
				
		panel.info = inputArgs;
		
		panel.contourName = inputArgs.contourName;
		panel.title = "AUS-CSH Analysis for " + panel.contourName;
		panel.minValue = inputArgs.minVal;
		panel.maxValue = inputArgs.maxVal;
		panel.frequencies = inputArgs.frequencies;
		panel.maxFrequency = inputArgs.frequencies[0];
	
		panel.generateBuckets();
		panel.addFrequenciesToBuckets();
		panel.generateDatasets();
		
		
		JFreeChart chart = ChartFactory.createHistogram(panel.title, X_AXIS_LABEL, Y_AXIS_LABEL, panel.line, PlotOrientation.VERTICAL, false, false, false);
				
		
		// XYLineAndShapeRenderer rend = new XYLineAndShapeRenderer();
		
		//chart.getXYPlot().setRenderer(new XYLineAndShapeRenderer());
		 
				
		
		XYItemRenderer rend = chart.getXYPlot().getRenderer();
		
		if(rend instanceof XYBarRenderer){
			XYBarRenderer bar = (XYBarRenderer) rend;
			bar.setShadowVisible(false);
			bar.setBarPainter(new StandardXYBarPainter());
		}
		
		
		
		JPanel chartPanel = new ChartPanel(chart);
		
		frame = new JFrame();
		frame.setTitle(panel.title);
		frame.setSize(600, 400);
		frame.add(chartPanel, BorderLayout.CENTER);
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// MIM doesn't take too kindly to outsiders...
		
		final CountDownLatch cdl = new CountDownLatch(1);
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				frame.setVisible(true);
				cdl.countDown();
			}
		});
		
		System.out.flush();
		
		//we need to keep the main thread alive until the frame is visible
		cdl.await();
		
		System.out.println("Leaving main; frame displayed");
	}
	

	private void generateBuckets() {
		// We are doing the buckets out of 100% of max, 
		// not out of absolute values
		binWidth = 100/numBuckets;
		
		double curVal = binWidth/2;
		
		buckets = new HistogramVal[(int)numBuckets];
		
		for(int i = 0; i < numBuckets; i++){
			buckets[i] = new HistogramVal(curVal, 0);
			curVal += binWidth;
		}
		
	}
	
	public void addFrequenciesToBuckets(){
		for(int i = 0; i < numBuckets; i++){
			buckets[i].frequency = (int) (100*(frequencies[i]/maxFrequency));
			
		}
	}
	
	
	public void generateDatasets(){
		line = new HistogramDataset();
		line.setType(HistogramType.FREQUENCY);
		
		List<Double> data = new LinkedList<Double>();
		
		for(HistogramVal bucket : buckets){
			for(int i = 0; i<bucket.frequency;i++){
				data.add(bucket.value);
			}
		}
		
		double[] doubleData = new double[data.size()];
		
		for(int i = 0; i<doubleData.length; i++){
			doubleData[i] = data.get(i);
		}
			
		line.addSeries(0, doubleData,(int) numBuckets, 0, 100);
		
		subsection = new HistogramDataset();
	}

}
