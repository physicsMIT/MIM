package sample.viewer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.swing.table.AbstractTableModel;

import com.mimvista.external.series.XMimDicomInfo;

/**
 * The table model stores a list of sorted DICOM tags and their associated values.
 * 
 * @author marpidone
 */
public class TagTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 1L;
	private static final String[] COLS = new String[] { "DICOM Tag", "Value" };
	
	/**
	 * Simple wrapper object that lets us combine a DICOM tag with its value so we
	 * can sort them together.
	 */
	private static class TagInfo implements Comparable<TagInfo> {
		public final int tag;
		public final Object value;
		public TagInfo(int tag, Object value) {
			this.tag = tag;
			this.value = value;
		}
		@Override
		public boolean equals(Object o) {
			if (o instanceof TagInfo) {
				TagInfo other = (TagInfo)o;
				return tag == other.tag;
			}
			return false;
		}
		@Override
		public int hashCode() {
			return tag;
		}
		@Override
		public int compareTo(TagInfo other) {
			return Integer.compare(tag, other.tag);
		}
	}
	
	private List<TagInfo> tags;
	
	public TagTableModel(XMimDicomInfo dicomInfo) {
		Set<Integer> topLevelTags = dicomInfo.getTags();
		tags = new ArrayList<TagInfo>(topLevelTags.size());
		
		for (int tag : topLevelTags) {
			tags.add(new TagInfo(tag, dicomInfo.getValue(tag)));
		}
		
		Collections.sort(tags);
	}
	
	@Override
	public int getColumnCount() {
		return COLS.length;
	}
	
	@Override
	public String getColumnName(int column) {
		return COLS[column];
	}

	@Override
	public int getRowCount() {
		return tags.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		TagInfo info = tags.get(row);
		
		switch (col) {
		case 0:
			return info.tag;
		case 1:
			return info.value;
		default:
			return "(???)";
		}
	}
}
