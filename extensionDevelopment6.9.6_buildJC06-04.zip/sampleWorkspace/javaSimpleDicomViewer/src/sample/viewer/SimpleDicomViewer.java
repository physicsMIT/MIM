package sample.viewer;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import com.mimvista.external.series.XMimDicomInfo;

/**
 * JFrame that contains a centered scrollable table displaying DICOM tags and their associated values.
 * 
 * @author marpidone
 */
public class SimpleDicomViewer extends JFrame {
	private static final long serialVersionUID = 1L;
	
	public SimpleDicomViewer(XMimDicomInfo dicomInfo) {
		buildUi(dicomInfo);
		pack();
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	private void buildUi(XMimDicomInfo dicomInfo) {
		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		TagTableModel tableModel = new TagTableModel(dicomInfo);
		JTable dicomTagTable = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(dicomTagTable);
		scrollPane.setPreferredSize(new Dimension(800, 800));
		mainPanel.add(scrollPane, BorderLayout.CENTER);
		
		dicomTagTable.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {
			private static final long serialVersionUID = 1L;
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
				value = formatDicomTagNumber((Integer)value);
				return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
			}
		});
		
		dicomTagTable.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {
			private static final long serialVersionUID = 1L;
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
				if (value instanceof XMimDicomInfo) {
					value = "Sequence...";
				} else if (value instanceof byte[]) {
					value = byteArrayToHexString((byte[])value, 15);
				}
				return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
			}
		});
		
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		JButton closeButton = new JButton("Close");
		closeButton.addActionListener(e->SimpleDicomViewer.this.dispose());
		buttonPanel.add(closeButton);
		mainPanel.add(buttonPanel, BorderLayout.SOUTH);
		
		setContentPane(mainPanel);
	}
	
	private String formatDicomTagNumber(int tag) {
		int group = tag >>> 16;
		int element = tag & 0x0000FFFF;
		
		StringBuilder sb = new StringBuilder("(");
		sb.append(String.format("%04x", group));
		sb.append(", ");
		sb.append(String.format("%04x", element));
		sb.append(")");
		return sb.toString();
	}
	
	private String byteArrayToHexString(byte[] array, int maxStringLen) {
		StringBuilder sb = new StringBuilder("[");
		for (int i = 0; i < array.length; i++) {
			sb.append(String.format("%02x", array[i]));
			if (array.length > maxStringLen && i > maxStringLen - 4) {
				break;
			}
			if (i < array.length - 1) {
				sb.append(", ");
			}
		}
		if (array.length > maxStringLen) {
			sb.append("...");
		} else {
			sb.append("]");
		}
		return sb.toString();
	}
}
