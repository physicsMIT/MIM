package sample.main;

import javax.swing.SwingUtilities;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimImage;

import sample.viewer.SimpleDicomViewer;

/**
 * Entry point for an extension that opens a simple DICOM viewer to view the DICOM tags for a series.
 * 
 * @author marpidone
 */
public class SimpleDicomViewerMain {
	@XMimEntryPoint(
			name="Simple DICOM Viewer",
			author="Matt Arpidone",
			category="Utilities",
			description="A very simple DICOM viewer.  Demonstrates how to read DICOM tags.",
			outputTypes={})
	public static Object[] runOnSession(final XMimSession session, final XMimImage image) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				SimpleDicomViewer viewer = new SimpleDicomViewer(image.getInfo().getDicomInfo());
				viewer.setVisible(true);
			}
		});
		
		return new Object[] {};
	}
}
