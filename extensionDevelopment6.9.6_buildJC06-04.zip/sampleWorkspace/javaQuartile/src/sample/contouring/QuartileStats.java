package sample.contouring;

import java.util.HashSet;
import java.util.Set;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimLogger;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.data.XMimRLEIterator;
import com.mimvista.external.linking.XMimLinkController;
import com.mimvista.external.points.XMimCoordSystem;
import com.mimvista.external.points.XMimNoxelPointF;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.points.XMimPointF;
import com.mimvista.external.points.XMimPointFactory;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.stats.XMimContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumericContourStat;

public class QuartileStats {
	private static final String statDesc = "Adds Quartiles to contour statistics.";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Quartiles Statistics",
			author="pjacobs",
			category="Statistics",
			description=statDesc)
	public static Object[] registerStat(XMimSession sess) {
		actuallyRegister(sess);

		//since we only want to register the stat, we can return nothing
		return new Object[0];
	}

	private static class SimpleQuantileStat implements XMimNumericContourStat {
		private final XMimSession targetSession;
		
		private final String fullName;
		private final String shortName;
		private final String statId;

		//The number of pieces that the histogram will be divided into (e.g. 2 = median, 4 = quartiles, 5 = quintiles, etc) 
		private final int d;
		
		//Which quantile to compute; should be greater than 0 and less than 'd'
		private final int n;

		public SimpleQuantileStat(XMimSession targetSession, String fullName, String shortName, String statId, int n, int d) {
			this.targetSession = targetSession;
			this.fullName = fullName;
			this.shortName = shortName;
			this.statId = statId;
			this.d = d;
			this.n = n;
		}

		@Override
		public XMimContourStatId getStatId() {
			//Other extensions (as well as the 'Lookup Statistic' WF command) can refer to our statistic using this ID and namespace
			return new XMimContourStatId(statId, "MIMEX");
		}
		@Override
		public Set<XMimContourStatId> getRequiredStats() {
			//Doesn't depend on any other stats
			return new HashSet<XMimContourStatId>();
		}
		@Override
		public String getStatName() {
			return fullName;
		}
		@Override
		public String getAbbreviatedName() {
			return shortName;
		}

		@Override
		public Number computeResult(XMimContourStatContext context) {
			return computeQuantile(targetSession, context, n, d);
		}
	}
	
	private static void actuallyRegister(final XMimSession sess) {
		SimpleQuantileStat q1 = new SimpleQuantileStat(sess, "First Quartile", "Quart1", "Quart1", 1, 4);
		SimpleQuantileStat q2 = new SimpleQuantileStat(sess, "Second Quartile", "Quart2", "Quart2", 2, 4);
		SimpleQuantileStat q3 = new SimpleQuantileStat(sess, "Third Quartile", "Quart3", "Quart3", 3, 4);
		
		//register the statistics on the session so that all contours will receive it
		sess.registerNewStat(q1);
		sess.registerNewStat(q2);
		sess.registerNewStat(q3);
	}
	
	
	public static class HistoWrapper{
		public int[] histo;
		public int binOffset;
		public int count;
		
		public HistoWrapper(int[] histo, int binOffset, int count) {
			this.histo = histo;
			this.binOffset = binOffset;
			this.count = count;
		}
	}

	public static HistoWrapper computeContourHistogram(XMimSession session, XMimContour contour){
		XMimLogger logger = session.createLogger();

		//XMimLogger can be used to output debugging information.
		//Extension logs go into the MIM log folder in a special directory
		//logger.debug("csv path "+csvFile.getAbsolutePath());
		//this is the image the contour is associated with (e.g. the CT)
		XMimImage image = contour.getMimImage();

		//links and points for converting between different spaces
		XMimLinkController link = session.getLinker();
		XMimPointFactory pf = session.getPointFactory();

		final XMimNoxelPointF imageNoxel = image.createNoxelPointF();
		final XMimCoordSystem dcm = pf.getDicomCoordSystem();
		XMimPointF imageDicom = pf.createPoint(
				image.getSpace(), 
				dcm,
				new float[image.getRawData().getDims().length]);


		//a few extra points, used to reduce memory allocation
		XMimPointF conPoint = link.toRawNoxel(imageNoxel, contour.getSpace());
		XMimNoxelPointF contourNoxelF = conPoint.getCoordSystem().toRawNoxel(conPoint);
		XMimNoxelPointI contourNoxelI = contourNoxelF.toRawDataLocation();

		//scaledImgData represents the raw voxels, scaled to the actual units (e.g. HU)
		//XMimNDArray scaledImgData = image.getScaledData();
		XMimNDArray data = image.getRawData();
		
		int[] tempHistogram = new int[Short.MAX_VALUE];
		int count = 0;
		
		short min = Short.MAX_VALUE;
		short max = Short.MIN_VALUE;
		
		//XMimRLEIterator returns the RLE compressed version of one
		//x-axis line of the contour boolean mask.  So, we calculate the on and off position,
		//and then output each voxel along that section
		for (XMimRLEIterator lineIter : contour.getData().getRleIterable()) {
			int start = -1;

			while (lineIter.hasNext()) {
				//find the location of the next change in the mask, and set it into contourNoxelI
				lineIter.advanceToNextNewValue(contourNoxelI);

				//based on getBoolean, determine if this is a start or end
				int end = -1;
				if (lineIter.getBoolean()) {
					start = contourNoxelI.getCoord(0);
					if (!lineIter.hasNext()) {
						end = lineIter.getCurrentLine().getDims()[0];
					}
				} else {
					end = contourNoxelI.getCoord(0);
				}

				//once we have a start and an end, write this section
				if (start != -1 && end != -1) {
					for(int i=start; i<end; i++) {
						contourNoxelI.setCoord(0, i);

						//this just changes our integer point into a float one
						contourNoxelI.toVoxelCenter(contourNoxelF);

						//convert the point from the contour space to the image space
						link.toRawNoxel(contourNoxelF, image.getSpace(), imageNoxel);

						short val = data.getShortValue(imageNoxel.toRawDataLocation());
						
						if(val < min){
							min = val;
						}
						if(val > max){
							max = val;
						}
						
						tempHistogram[val] ++;
						count++;
					}
				}
			}
		}
		
		int[] realHisto = new int[max - min + 1];
		System.arraycopy(tempHistogram, min, realHisto, 0, realHisto.length);
		
		//logger.error("Computed histogram with " + realHisto.length + " bins.");
		//logger.error("The min value is " + min);
		
		return new HistoWrapper(realHisto, min, count);


	}

	private static int findValue(HistoWrapper histo, int target){
		int i;
		for(i = 0; i < histo.histo.length; i++){
			
			target -= histo.histo[i];

			if(target <= 0){
				break;
			}
		}
		
		return i;
	}
	
	private static Number computeQuantile(XMimSession sess, XMimContourStatContext context, int n, int d) {
		
		float slope = context.getContour().getMimImage().getInfo().getRescaleSlope();
		float intercept = context.getContour().getMimImage().getInfo().getRescaleIntercept();
		
		//XMimLogger logger = sess.createLogger();

		HistoWrapper histo = computeContourHistogram(sess, context.getContour());
		
		if (n == 1) {
			for (int i=0; i<histo.histo.length; i++) {
				for (int j=0; j<histo.histo[i]; j++) {
					System.out.println(intercept + (histo.binOffset+i)*slope);
				}
			}
		}
		
		float percentile = (1.0f*n)/d;
		
		float np = percentile * (histo.count+1) - 1;
		
		System.out.println("N: "+n+" NP: "+np);
		
		int vk = findValue(histo, (int)Math.floor(np)+1);
		int vkp1 = findValue(histo, (int)Math.ceil(np)+1);
		
		float dec = np - (int)Math.floor(np);
		
		float v1 = intercept + (histo.binOffset+vk)*slope;
		float v2 = intercept + (histo.binOffset+vkp1)*slope;
		
		return v1 + dec*(v2-v1);
	}

}
