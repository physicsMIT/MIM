package sample.stats;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimHistogram;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimDose;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimDoseStatId;
import com.mimvista.external.stats.XMimDoseVolumeHistogram;

public class DataMining {	
	private static final XMimContourStatId volumeStat = new XMimContourStatId("VOLUME", "MIM");
	
	private File csvFile;
	private XMimSession session;
	private XMimDose dose;
	private List<ContourStats> contourStats = new ArrayList<ContourStats>();
	private JsonArray generalStatistics;
	
	/**
	 * The contours should be the same as the ones in the histogram and the assignedDose should be the one used to make the histogram.
	 * @param sess
	 * @param doseVolumeHistogram
	 * @param assignedDose
	 * @param relevantContours
	 */
	@XMimEntryPoint(
			author = "Julie A Kaplan", 
			name = "Data Mining", 
			description="Extracts Data from the Dose and puts it into a spreadsheet.")
	public void mineData(XMimSession sess, XMimDose assignedDose, String configurationFileLocation) {
		session = sess;
		dose = assignedDose;
		try {
			readConfig(configurationFileLocation);
			writeToFile();
		} catch (Exception e) {
			session.createLogger().error("Data Mining error", e);
		}
	}
	
	/**
	 * Reads the configuration file specified
	 */
	private void readConfig(String configLoc) {
		JsonParser parser = new JsonParser();
		try {
			JsonObject json = parser.parse(new FileReader(configLoc)).getAsJsonObject();
			csvFile = new File(json.get("Output Location").getAsString());
			generalStatistics = json.get("General Statistics").getAsJsonArray();
			JsonArray contours = json.get("Contours").getAsJsonArray();
			for (int i=0; i < contours.size(); i++) {
				JsonObject contour = contours.get(i).getAsJsonObject();
				String wantedName = contour.get("Contour Name").getAsString();
				XMimContour matchingContour = null;
				boolean regex = contour.get("Regex Used").getAsBoolean();
				for (XMimContour doseContour : dose.getOwner().getContours()) {
					String actualName = doseContour.getInfo().getName();
					if (regex) {
						if (Pattern.compile(wantedName, Pattern.CASE_INSENSITIVE).matcher(actualName).matches()) {
							matchingContour = doseContour;
							break;
						}
					} else {
						if (actualName.equalsIgnoreCase(wantedName)) {
							matchingContour = doseContour;
							break;							
						}
					}
				}
				contourStats.add(new ContourStats(matchingContour, contour.get("Contour Statistics").getAsJsonArray()));
				if (matchingContour==null) {
					session.createLogger().warn("No contour matches pattern "+wantedName);
				}
			}
		} catch (JsonParseException e) {
			session.createLogger().error("Could not parse json",e);
		} catch (FileNotFoundException e) {
			session.createLogger().error("Could not find configuration file",e);
			JOptionPane.showMessageDialog(session.getAppInstance().getMainWindow(), "Can't find config file! " + e);
		}
	}
	
	/**
	 * Opens the file and writes to it
	 */
	private void writeToFile() {
		try {
			if (!csvFile.getName().toLowerCase().endsWith(".csv")) {
				csvFile = new File(csvFile.getParent(), csvFile.getName() + ".csv");
			}
			boolean createHeader = !csvFile.exists();
			FileOutputStream fileOutput = new FileOutputStream(csvFile, true);
			
			try {
				PrintWriter writer = new PrintWriter(fileOutput);				
				try {
					if (createHeader) {
						initializeHeader(writer);
					}
					writeOutput(writer);
				} finally {
					writer.close();
				}
			} finally {
				fileOutput.close();
			}
		} catch (IOException ex) {
			session.createLogger().error("Error in DICOM to CSV extension...", ex);
			JOptionPane.showMessageDialog(session.getAppInstance().getMainWindow(), "Can't write to the CSV file!  " + ex);
		} catch (Throwable t) {
			session.createLogger().error("Error in DICOM to CSV extension", t);
			JOptionPane.showMessageDialog(session.getAppInstance().getMainWindow(), "An unexpected error occurred: " + t);
		}
	}

	private void initializeHeader(PrintWriter writer) {
		for (JsonElement stat : generalStatistics) {
			writer.print(csvString(stat.getAsJsonObject().get("Statistic Name").getAsString()) + ",");
		}
		for (ContourStats cstat : contourStats) {
			for (JsonElement stat : cstat.wantedStats) {
				writer.print(csvString(stat.getAsJsonObject().get("Statistic Name").getAsString()) + ",");
			}
		}
		writer.println();
	}
	
	private String csvString(String orig) {
		return '"'+orig+'"';
	}

	/**
	 * Actually writes the output
	 * @param writer
	 */
	private void writeOutput(PrintWriter writer) {
		writeGeneralStats(writer);
		for (ContourStats cstat : contourStats) {
			for (JsonElement stat : cstat.wantedStats) {
				writer.print('"');
				if (cstat.contour!= null) {
					try {
						writer.print(getStat(cstat.contour, stat));
					} catch (InvalidStatisticError e) {
					}
				}
				writer.print("\",");
			}
		}
		writer.println();
	}
	
	private void writeGeneralStats(PrintWriter writer) {
		for (int i = 0; i< generalStatistics.size(); i++) {
			String stat = generalStatistics.get(i).getAsJsonObject().get("Statistic Type").getAsString();
			String result;
			if ("DOSE STRING".equalsIgnoreCase(stat)) {
				result = dose.getDoseDescription();
			} else if ("DICOM".equalsIgnoreCase(stat)) {
				String tag = generalStatistics.get(i).getAsJsonObject().get("Tag").getAsString();
				Object value = dose.getInfo().getDicomInfo().getValue(tag);
				result = (value == null) ? "" : dose.getInfo().getDicomInfo().getValue(tag).toString();
			} else {
				try {
					result = Double.toString(getStat(null, generalStatistics.get(i)));
				} catch (InvalidStatisticError e) {
					result = "";
				}
			}
			writer.print(csvString(result)+",");
		}		
	}
	
	private double getStat(XMimContour contour, JsonElement einfo) throws InvalidStatisticError {
		if (einfo.isJsonPrimitive()) {
			return einfo.getAsDouble();
		}
		JsonObject info = einfo.getAsJsonObject();
		String inputType = info.get("Statistic Type").getAsString();
		if ("RX DOSE".equalsIgnoreCase(inputType)) {
			return dose.getRxDose();
		} else if ("MAX DOSE".equalsIgnoreCase(inputType)) {
			return getMaxDose();
		} else if ("MIN DOSE".equalsIgnoreCase(inputType)) {
			return getMinDose();
		} else if ("NUMBER".equalsIgnoreCase(inputType)) {
			return info.get("Value").getAsDouble();
		} else if ("+".equalsIgnoreCase(inputType)) {
			double total = 0;
			for (JsonElement e: info.get("Value").getAsJsonArray()) {
				total+=getStat(contour, e);
			}
			return total;
		} else if ("-".equalsIgnoreCase(inputType)) {
			JsonArray elements = info.get("Value").getAsJsonArray();
			double total = getStat(contour, elements.get(0));
			for (int i=1; i<elements.size(); i++) {
				total-=getStat(contour, elements.get(i));
			}
			return total;
		} else if ("*".equalsIgnoreCase(inputType)) {
			double total = 1;
			for (JsonElement e: info.get("Value").getAsJsonArray()) {
				total*=getStat(contour, e);
			}
			return total;
		} else if ("/".equalsIgnoreCase(inputType)) {
			JsonArray elements = info.get("Value").getAsJsonArray();
			double total = getStat(contour, elements.get(0));
			for (int i=1; i<elements.size(); i++) {
				total/=getStat(contour, elements.get(i));
			}
			return total;
		} else if ("DOSE STATISTIC".equalsIgnoreCase(inputType)) {
			XMimDoseStatId stat = new XMimDoseStatId(info.get("Value").getAsString(), "MIM");
			Number n = dose.getStatistic(stat, contour);
			if (n==null)  {
				session.createLogger().error("Did not get result for dose statistic: "+stat.getStatId());
				throw new InvalidStatisticError();
			}
			return n.doubleValue();
		} else if ("CONTOUR STATISTIC".equalsIgnoreCase(inputType)) {
			XMimContourStatId stat = new XMimContourStatId(info.get("Value").getAsString(), "MIM");
			Number n = contour.getStatistic(stat);
			if (n==null)  {
				session.createLogger().error("Did not get result for contour statistic: "+stat.getStatId());
				throw new InvalidStatisticError();
			}
			return n.doubleValue();
		} else if ("VOLUME AT DOSE".equalsIgnoreCase(inputType)) {
			double result = volumeRecievedDose(contour, convert(true, info.get("Source Mode"), getStat(contour, info.get("Value")), dose.getRxDose()));
			return convert(false, info.get("Result Mode"), result, contour.getStatistic(volumeStat).doubleValue());
		} else if ("DOSE AT VOLUME".equalsIgnoreCase(inputType)) {
			double result = doseAtVolume(contour, convert(true, info.get("Source Mode"), getStat(contour, info.get("Value")), contour.getStatistic(volumeStat).doubleValue()));
			return convert(false, info.get("Result Mode"), result, dose.getRxDose());
		} else if ("MAX DOSE OF CONTOUR".equalsIgnoreCase(inputType)){
			double result = maxDoseForContour(contour);
			return convert(false, info.get("Result Mode"), result, dose.getRxDose());
		} else if ("MIN DOSE OF CONTOUR".equalsIgnoreCase(inputType)){
			double result = minDoseForContour(contour);
			return convert(false, info.get("Result Mode"), result, dose.getRxDose());
		} else if ("MEAN DOSE OF CONTOUR".equalsIgnoreCase(inputType)){
			double result = meanDoseForContour(contour);
			return convert(false, info.get("Result Mode"), result, dose.getRxDose());
		} else {
			session.createLogger().warn("Unknown Statistic Type "+inputType, new Throwable());
			return Double.NEGATIVE_INFINITY;
		}
	}

	/**
	 * @param dose
	 * @return Minimum value of the dose
	 */
	private float getMinDose() {
		XMimNDArray doseData = dose.getScaledData();
		int[] doseDims = doseData.getDims();
		float doseMin = Float.POSITIVE_INFINITY;
		XMimNoxelPointI dosePos = dose.createNoxelPointI();
		
		for (int z=0; z<doseDims[2]; z++) {
			dosePos.setCoord(2, z);
			for (int y=0; y<doseDims[1]; y++) {
				dosePos.setCoord(1, y);
				for (int x=0; x<doseDims[0]; x++) {
					dosePos.setCoord(0, x);
					float doseVal = doseData.getFloatValue(dosePos);
					if (doseVal<doseMin) doseMin = doseVal;
				}
			}
		}
		
		return doseMin;
	}
	
	/**
	 * @param dose
	 * @return Maximum value of the dose
	 */
	private float getMaxDose() {
		XMimNDArray doseData = dose.getScaledData();
		int[] doseDims = doseData.getDims();
		float doseMax = Float.NEGATIVE_INFINITY;
		XMimNoxelPointI dosePos = dose.createNoxelPointI();
		
		for (int z=0; z<doseDims[2]; z++) {
			dosePos.setCoord(2, z);
			for (int y=0; y<doseDims[1]; y++) {
				dosePos.setCoord(1, y);
				for (int x=0; x<doseDims[0]; x++) {
					dosePos.setCoord(0, x);
					float doseVal = doseData.getFloatValue(dosePos);
					if (doseVal>doseMax) doseMax = doseVal;
				}
			}
		}
		
		return doseMax;
	}
	
	private double convert(boolean isFrom, JsonElement jmode, double original, double stat) {
		String mode;
		if (jmode==null) {
			mode="RAW";
		} else {
			mode = jmode.getAsString();
		}
		double changeAmount = 1;
		if ("PERCENT".equalsIgnoreCase(mode)) {
			changeAmount = stat/100.0;
		} else if ("FRACTION".equalsIgnoreCase(mode)) {
			changeAmount = stat;
		} else if (!"RAW".equalsIgnoreCase(mode)) {
			session.createLogger().warn("Unknown Statistic Mode "+mode, new Throwable());
		}
		if (isFrom) {
			return original*changeAmount;
		} else {
			return original/changeAmount;
		}
	}
	
	private double doseAtVolume(XMimContour contour, double minimumAmount) {
		XMimHistogram hist = dose.generateDVHForContour(contour).getHistogram().get(0);
		double max = 0.0;
		double total = 0.0;
		for (int i=0; i<hist.binValues().size(); i++) {
			total+=hist.binWidths().get(i);
			if (hist.binValues().get(i) >= minimumAmount) {
				max =total;
			} else {
				break;
			}
		}
		return max+=getMinDose();
	}
	
	// NOTE: all of the following 'dose for contour' functions assume that you're using a MIM-generated, cumulative DVH
	
	private double maxDoseForContour(XMimContour contour){
	
		XMimDoseVolumeHistogram dvh = dose.generateDVHForContour(contour);
		double doseOfFirstBin = dvh.getInfo().get(0).getDoseOfFirstBin().doubleValue();
		XMimHistogram hist = dvh.getHistogram().get(0);
		
		double max = doseOfFirstBin;
		for (int i=0; i<hist.binValues().size(); i++) {
			if (hist.binValues().get(i) > 0) {
				max += hist.binWidths().get(i);
			}
		}
		return max;
	}
	
	private double minDoseForContour(XMimContour contour){
	
		XMimDoseVolumeHistogram dvh = dose.generateDVHForContour(contour);
		double doseOfFirstBin = dvh.getInfo().get(0).getDoseOfFirstBin().doubleValue();
		XMimHistogram hist = dvh.getHistogram().get(0);
		
		if(hist.binValues().get(0) <= 0 ){
			return 0;
		}
		
		double doseMin = doseOfFirstBin;
		for (int i = 0; i < hist.binValues().size()-1; i++) {
			if (Math.abs(hist.binValues().get(i) - hist.binValues().get(i+1)) >  0.0001){
				break;
			} 
		
			doseMin += hist.binWidths().get(i);

		}
		return doseMin;
	}
	
	private double meanDoseForContour(XMimContour contour){
		
		XMimDoseVolumeHistogram dvh = dose.generateDVHForContour(contour);
		double doseOfFirstBin = dvh.getInfo().get(0).getDoseOfFirstBin().doubleValue();
		XMimHistogram hist = dvh.getHistogram().get(0);
		
		double doseVal = doseOfFirstBin;
		double vol = 0;
		double volTotal = 0;
		double accum = 0;
		
		int size = hist.binValues().size();
		
		for(int i = 0; i < size-1; i++){
			
			doseVal += hist.binWidths().get(i);
			vol = hist.binValues().get(i) - hist.binValues().get(i+1);
			
			accum += (doseVal-hist.binWidths().get(i)/2) * vol;
			volTotal += vol;
		}
		
		doseVal += hist.binWidths().get(size-1) / 2;
		vol = hist.binValues().get(size-1);
		accum += doseVal * vol;
		volTotal += vol;
		
		if(volTotal == 0){
			return 0;
		}
	
		return accum / volTotal;
	}
	
	/**
	 * 
	 * @param index (which contour)
	 * @param minimumAmount
	 * @return the percent of the contour that recieved more than the minimumAmount of dosage
	 */
	private double volumeRecievedDose(XMimContour contour, double minimumAmount) {
		minimumAmount-=getMinDose();
		XMimHistogram hist = dose.generateDVHForContour(contour).getHistogram().get(0);
		if (minimumAmount<=hist.binWidths().get(0)) {
			return hist.binValues().get(0);
		}
		double total = 0.0;
		for (int i=1; i<hist.binWidths().size(); i++) {
			total+=hist.binWidths().get(i);
			if (total>=minimumAmount) {
				double valueGap = hist.binWidths().get(i);
				double prevFactor = 1.0 - (minimumAmount - (total - hist.binWidths().get(i)))/valueGap;
				double thisFactor = 1.0 - (total - minimumAmount)/valueGap;
				return (prevFactor*hist.binValues().get(i-1)+thisFactor*hist.binValues().get(i));
			}
		}
		return 0;
	}
	
	private class ContourStats {
		public XMimContour contour;
		public JsonArray wantedStats;
		
		public ContourStats(XMimContour cont, JsonArray stats) {
			contour = cont;
			wantedStats = stats;
		}
	}
	
	private class InvalidStatisticError extends Exception {
		
	}
}
