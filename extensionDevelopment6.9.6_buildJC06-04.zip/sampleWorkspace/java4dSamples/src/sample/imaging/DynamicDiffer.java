package sample.imaging;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.data.XMimNDArray;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.series.XMimMutableImage;
import com.mimvista.external.series.XMimSeriesView;

public class DynamicDiffer {
	private static final String diffDesc = "Highlights differences between adjacent 4D frames.";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="4D Diff Revealer", 
			author="MIM", 
			description=diffDesc, 
			category="4D",
			outputTypes={XMimSeriesView.class}, 
			outputNames={"Diff Images"})
	public static Object[] processImage(XMimSession sess, XMimImage img) {
		DynamicDiffer ander = new DynamicDiffer(img);
		XMimImage result = ander.produceResult();

		//Once we finish processing the result, add it to the session so it can be displayed
		XMimSeriesView sv = sess.addImageAndReturnView(result, "4D Diff");
		
		//Our @XMimEntryPoint says we return one XMimImage object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new Object[]{sv};
	}

	XMimImage img;
	
	public DynamicDiffer(XMimImage dynamicImage) {
		this.img = dynamicImage;
		if (img.getRawData().getDimensionCount() < 4) {
			//A more user-friendly option would be to use JOptionPane to warn the user
			throw new RuntimeException("This extension only works on 4D images!");
		}
	}
	
	public XMimImage produceResult() {
		//MIMextensions don't allow a volume to be modified in place
		//So, create a mutable copy so we can edit it
		XMimMutableImage res = img.getMutableCopy();
		
		//a raw array contains the short values present in the DICOM file
		//before rescale slope and intercept are calculated
		XMimNDArray srcData = img.getRawData();
		
		XMimMutableNDArray resultData = res.getRawData();
		
		//[x,y,z,t] dimensions
		int[] dims = resultData.getDims();
		
		XMimNoxelPointI curLoc = res.getSpace().createNoxelPoint().toRawDataLocation();
		for (int x=0; x<dims[0]; x++) {
			curLoc.setCoord(0, x);
			for (int y=0; y<dims[1]; y++) {
				curLoc.setCoord(1, y);
				for (int z=0; z<dims[2]; z++) {
					curLoc.setCoord(2, z);
					for (int i=0; i<dims[3]; i++) {
						//access frame i and i+1
						curLoc.setCoord(3, (i+1)%dims[3]);
						short val1 = srcData.getShortValue(curLoc);
						curLoc.setCoord(3, i);
						short val2 = srcData.getShortValue(curLoc);
						
						//if they are 'sufficiently' different, set the result to the average
						int diff = Math.abs(val1-val2);
						if (diff > 100) {
							resultData.setValue(curLoc, (short)((val1+val2)/2f));
						} else {
							resultData.setValue(curLoc, (short)0);
						}
					}
				}
			}
		}
		
		return res;
	}
	
}
