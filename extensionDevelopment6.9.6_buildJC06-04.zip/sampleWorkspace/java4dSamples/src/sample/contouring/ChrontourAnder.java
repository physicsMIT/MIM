package sample.contouring;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.points.XMimNoxelPointI;

public class ChrontourAnder {
	private static final String mergeDesc = "Performs an 'AND' operation across all frames of a 4D contour.";
	
	/* 
	 * 	@XMimEntryPoint tells MIM that this function can be used to start a MIMextension
	 * 		Meta-data entered here will display in the extension launcher inside MIM
	 */
	@XMimEntryPoint(
			name="Chrontour 'AND'", 
			author="MIM", 
			category="Contouring",
			description=mergeDesc,
			outputTypes={XMimContour.class}, 	//by specifying output types and names
			outputNames={"Merged Chrontour"})	//we allow integration with worklows
	public static Object[] processChrontour(XMimSession sess, XMimContour con) {
		ChrontourAnder ander = new ChrontourAnder(con);
		
		XMimContour result = ander.produceResult();

		//Our @XMimEntryPoint says we return one XMimContour object, so do that here
		//This allows our MIMextension to integrate with workflows
		return new Object[]{result};
	}

	private XMimContour chrontour;
	
	public ChrontourAnder(XMimContour chron) {
		//we use the word chrontour to indicate a 4D-contour
		this.chrontour = chron;
		
		if (chrontour.getDims().length < 4) {
			throw new RuntimeException("This extension only works on 4D contours!");
		}
	}
	
	public XMimContour produceResult() {
		String newName = "ANDED "+chrontour.getInfo().getName();
		XMimContour result = chrontour.getMimImage().createNewContour(newName);
		
		//this is the binary mask of contour data
		//since we just created result, it is blank
		XMimMutableNDArray resultData = result.getData();
		
		//and here is our input
		XMimMutableNDArray allFrames = chrontour.getData();
		
		//[x,y,z,t] dimensions
		int[] dims = allFrames.getDims();
		
		XMimNoxelPointI curLoc = chrontour.getSpace().createNoxelPoint().toRawDataLocation();
		for (int x=0; x<dims[0]; x++) {
			curLoc.setCoord(0, x);
			for (int y=0; y<dims[1]; y++) {
				curLoc.setCoord(1, y);
				nextZ:for (int z=0; z<dims[2]; z++) {
					curLoc.setCoord(2, z);
					for (int i=0; i<dims[3]; i++) {
						curLoc.setCoord(3, i);
						//one time-point is off, so continue to the next voxel
						if (!allFrames.getBooleanValue(curLoc)) {
							continue nextZ;
						}
					}
					//if all frames were on, set the value to true for each output frame
					for (int i=0; i<dims[3]; i++) {
						curLoc.setCoord(3, i);
						resultData.setValue(curLoc, true);
					}
				}
			}
		}
		
		//tell MIM we're finished editing this contour so the screen will update
		result.redrawCompletely();
		
		return result;
		
	}
	
}
