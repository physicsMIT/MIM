package sample.contouring;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JOptionPane;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.series.XMimImage;
import com.mimvista.external.stats.XMim4DContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimNumeric4DContourStat;

public class MidVentilationInternal {
	private static final String name = "Midventilation (Internal)";
	private static final String desc = "Compute the midventilation frame of a 4D series based on internal anatomic motion";

	@XMimEntryPoint(
			name = name,
			author = "MIM", 
			category = "Filters", 
			description = desc, 
			outputTypes = {Float.class},
			outputNames={"Mid-ventilation frame"})
	public static Object[] run(final XMimSession sess, XMimImage image, List<XMimContour> contour) { 
		if(contour.size() != 1){
			sess.createLogger().warn("This extension must take exactly one contour. Found: "+ contour.size()+".",  new IllegalArgumentException("Must take exactly one contour"));
			JOptionPane.showMessageDialog(null, "This extension must take exactly one contour. Found: "+ contour.size()+".");
			return new Object[0];
		}
		
		XMimContour con = contour.get(0);
		final int frameCount = image.getRawData().getDims()[3];
		MidVFrameNumber midv = new MidVFrameNumber(sess, frameCount);
		con.registerNew4DStat(midv);
		Number val = con.get4DStatistic(midv.getStatId());
		
		if(val == null || val.intValue() == -1) {
			sess.createLogger().error("Failed to compute Midventilation frame");
			JOptionPane.showMessageDialog(null, "Midventilation frame computation failed");
			return new Object[0];
		}
		
		return new Object[] {val.floatValue()};
	}
	
	private static final class MidVFrameNumber implements XMimNumeric4DContourStat {
		private final XMimSession sess;
		
		// The javadoc for XMimContourStatId defines the built-in stats in MIM
		private final XMimContourStatId centroidX = new XMimContourStatId("CENTROIDX", "MIM");
		private final XMimContourStatId centroidY = new XMimContourStatId("CENTROIDY", "MIM");
		private final XMimContourStatId centroidZ = new XMimContourStatId("CENTROIDZ", "MIM");
		private final int frameCount;
		public Integer frameNum = -1;

		private MidVFrameNumber(XMimSession sess, int frameCount) {
			this.sess = sess;
			this.frameCount = frameCount;
		}

		@Override
		public String getStatName() {
			return name;
		}

		public Integer getFrameNum() {
			return this.frameNum;
		}

		@Override
		public XMimContourStatId getStatId() {
			// the statId we return here can potentially allow other extensions
			// to be derived from our stat
			return new XMimContourStatId("MIDV_INTERNAL", "MIMEX");
		}

		@Override
		public Set<XMimContourStatId> getRequiredStats() {
			HashSet<XMimContourStatId> rv = new HashSet<XMimContourStatId>();

			// by telling MIM we depend on the centroid statistics,
			// we ensure that they will always be computed before our statistic
			rv.add(centroidX);
			rv.add(centroidY);
			rv.add(centroidZ);

			return rv;
		}

		@Override
		public String getAbbreviatedName() {
			return name;
		}

		@Override
		public Number computeResult(XMim4DContourStatContext context) {
			// first, lets go through and retrieve MIM's centroid calculations
			// for each frame
			List<float[]> centroids = new ArrayList<float[]>();
			for (int w = 0; w < frameCount; w++) {
				sess.createLogger().info("going to retrieve w: " + w);
				Number xValue = context.getNumericResult(centroidX, w);
				Number yValue = context.getNumericResult(centroidY, w);
				Number zValue = context.getNumericResult(centroidZ, w);

				float[] centroid = new float[] { xValue.floatValue(), yValue.floatValue(), zValue.floatValue(), };
				centroids.add(centroid);
			}

			float[] meanCentroid = calcMeanCentroid(centroids);
			sess.createLogger().info(Arrays.toString(meanCentroid));
			// calc the centroid that is the closest to the mean centroid value
			float[] closest = { -1f, -1f, -1f };
			float minimalDisplacement = Float.MAX_VALUE;
			for (int i = 0; i < centroids.size(); i++) {
				float displacement = dist(centroids.get(i), meanCentroid);
				if (displacement < minimalDisplacement) {
					minimalDisplacement = displacement;
					closest = centroids.get(i);
				}
			}
			
			frameNum = centroids.indexOf(closest) + 1; //frames are 1-indexed
			sess.createLogger().info("mid v frame: " + frameNum);
			return frameNum;
		}

		/**
		 * Calculates the mean centroid from the centroid map
		 * 
		 * @param centroids
		 * @return
		 */
		private float[] calcMeanCentroid(List<float[]> centroids) {
			float[] mean = new float[3];
			
			for(float[] centroid : centroids) {
				for(int i = 0; i < 3; ++i) {
					mean[i] += centroid[i];
				}
			}
			
			for(int i = 0; i < 3; ++i) {
				mean[i] /= centroids.size();
			}
			
			return mean;
		}

		/**
		 * Calc the l2 distance between two float[]
		 */
		private float dist(float[] one, float[] two) {
			float dist = 0;
			for (int i = 0; i < one.length; i++) {
				float diff = one[i]-two[i];
				dist += diff*diff;
			}
			
			return (float) Math.sqrt(dist);
		}
	}
}
