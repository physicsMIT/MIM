package sample;

import java.awt.Component;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimHistogram;
import com.mimvista.external.stats.XMimDoseVolumeHistogram;
import com.mimvista.external.stats.XMimDoseVolumeHistogramInfo;

public class DvhToCsv {

	@XMimEntryPoint(
			name="DvhToCsv",
			author="MIM",
			description="Writes DVH out to a CSV file.",
			website="www.mimsoftware.com",
			outputTypes={},
			category="Dose", 
			institution="MIM Software", 
			version="1.2")
	public Object[] runOnSession(XMimSession session, XMimDoseVolumeHistogram dvhToOutput) {
		Component parentWindow = session.getAppInstance().getMainWindow();
		
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select a destination for the CSV file");
		chooser.setFileFilter(new FileFilter() {
			@Override
			public boolean accept(File f) {
				return f.getName().toLowerCase().endsWith(".csv");
			}
			@Override
			public String getDescription() {
				return "CSV files";
			}
		});
		int result = chooser.showSaveDialog(parentWindow);
		
		if (result != JFileChooser.APPROVE_OPTION) return null;
		
		File csvFile = chooser.getSelectedFile();
		if (!csvFile.getName().toLowerCase().endsWith(".csv")) {
			csvFile = new File(csvFile.getParent(), csvFile.getName() + ".csv");
		}
		PrintWriter writer = null;
				
		try {
			writer = new PrintWriter(new FileOutputStream(csvFile, true));
			writer.print("values,bin,contour");
			
			List<? extends XMimHistogram> hists = dvhToOutput.getHistogram();
			List<? extends XMimDoseVolumeHistogramInfo> infos = dvhToOutput.getInfo();
			
			for(int h=0; h<hists.size(); h++) {
				XMimHistogram hist = hists.get(h);
				XMimDoseVolumeHistogramInfo hinfo = infos.get(h);
				
				String contourName = "UNKNOWN";
				List<String> reffedCons = hinfo.getReferencedContours();
				
				if (reffedCons != null && reffedCons.size() == 1) {
					contourName = reffedCons.get(0);
				}
						
				List<Double> vals = hist.binValues();
				List<Double> widths = hist.binWidths();
				
				writer.println();
				double bin = infos.get(h).getDoseOfFirstBin().doubleValue();
						
				for(int i = 0 ; i < Math.max(vals.size(), widths.size()) ; i++) {
					double val = 0;
					double width = 0;
					//these two lists should be the same sizez, the check is just in case.
					if(i < vals.size()) {
						val = vals.get(i);
					}
					if(i < widths.size()) {
						width = widths.get(i);
						bin += width;
					} else {
						bin = 0;
					}
					writer.print(val+","+bin+","+contourName);
					writer.println();
				}
			}
		} catch (IOException ex) {
			session.createLogger().error("Error in DICOM to CSV extension...", ex);
			JOptionPane.showMessageDialog(parentWindow, "Can't write to the CSV file!  " + ex);
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
		
		return null;
	}
	
}
