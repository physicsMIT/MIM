package sample;

import java.awt.Component;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.mimvista.external.contouring.XMimContour;
import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimHistogram;
import com.mimvista.external.series.XMimDose;
import com.mimvista.external.stats.XMimContourStatContext;
import com.mimvista.external.stats.XMimContourStatId;
import com.mimvista.external.stats.XMimDoseVolumeHistogram;
import com.mimvista.external.stats.XMimDoseVolumeHistogramInfo;
import com.mimvista.external.stats.XMimNumericContourStat;
import com.mimvista.external.control.XMimLogger;


public class CustomConstraint {
	@XMimEntryPoint(
			name="CustomConstraint",
			author="Shoshana Ginsburg",
			description="",
			website="www.mimsoftware.com",
			outputTypes={},
			category="Dose", 
			institution="MIM Software", 
			version="1.0")
	public Object[] runOnSession(XMimSession session, XMimDose doseVolume, XMimContour contour) {
		
		double dose = computeCustomConstaint(session, doseVolume, contour);
		
		return null;
	}

	private static double computeCustomConstaint(XMimSession session, XMimDose doseVolume, XMimContour contour) {
		XMimDoseVolumeHistogram dvh = doseVolume.generateDVHForContour(contour);
			
		double targetVolume = 0.1; //ml
		double dose = 0;
		XMimHistogram histogram = dvh.getHistogram().get(0);

		XMimLogger logger = session.createLogger();


		List<Double> binValues = histogram.binValues();
		List<Double> binWidths = histogram.binWidths();
		double targetValue = binValues.get(0) - targetVolume; 
		
		if (targetValue<0){
			logger.error("Invalid target volume.");
		}
		
		if (targetValue>=0){
			int i = 0;		
			while (binValues.get(i)>=targetValue){
				dose = dose + binWidths.get(i);
				i++;
				if (i==binValues.size()){
					break;
				}
				
			}
			
			if (targetValue==0){
				dose = dose + binWidths.get(i);
			}

			if (i<binValues.size()){
				double volNext = binValues.get(i);
				double volPrev = binValues.get(i-1);
				dose = dose + ( ( targetValue - volPrev) / (volNext - volPrev) ) * (binWidths.get(i));
			}
			logger.error("Custom constraint output: "+dose);
		}
		return dose;
	}
	
	@XMimEntryPoint(
			name="CustomConstraintStatistic",
			author="Shoshana Ginsburg",
			description="",
			website="www.mimsoftware.com",
			outputTypes={},
			category="Dose", 
			institution="MIM Software", 
			version="1.0")
	public Object[] registerStat(XMimSession session, XMimDose doseVolume) {
		
		actuallyRegister(session,doseVolume,0.1);
		
		return null;
	}
	
	private static void actuallyRegister(final XMimSession sess, final XMimDose doseVolume, final double targetVolume) {
		
		//register the statistic on the session so that all contours will receive it
		sess.registerNewStat(new XMimNumericContourStat() {
			@Override
			public String getStatName() {
				return "Custom constraint, volume minus "+targetVolume;
			}
			@Override
			public XMimContourStatId getStatId() {
				//other extensions could refer to our statistic using this ID and namespace
				return new XMimContourStatId("CCDVH", "MIMEX");
			}
			@Override
			public Set<XMimContourStatId> getRequiredStats() {
				//MIM will compute these stats before computing ours
				Set<XMimContourStatId> reqs = new HashSet<XMimContourStatId>();
				return reqs;
			}
			@Override
			public String getAbbreviatedName() {
				//there is never enough space...
				return "CCDVH";
			}
			@Override
			public Number computeResult(XMimContourStatContext context) {
				//do the actual work to compute the statistic
				XMimContour contour = context.getContour();
				double dose = computeCustomConstaint(sess, doseVolume, contour);
				return dose;
			}
		});
	}

}
