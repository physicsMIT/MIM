package sample.xform;

import com.mimvista.external.control.XMimEntryPoint;
import com.mimvista.external.control.XMimSession;
import com.mimvista.external.data.XMimMutableNDArray;
import com.mimvista.external.linking.XMimDeformation;
import com.mimvista.external.points.XMimNoxelPointI;
import com.mimvista.external.series.XMimImage;

public class WarpTest {
	
	private static final String desc = "Applies a swirl transform to a deformation field and re-creates the deformed image " +
			"based on the modified transform.";
	
	@XMimEntryPoint(name="Deformation Swirler", author="Andy Lee", description=desc, outputTypes={})
	public static void testWarp(XMimSession sess, XMimImage deformedSecondary, XMimImage secondary) {
		XMimDeformation warp = sess.getLinker().getDeformationField(deformedSecondary.getSpace(), secondary.getSpace());
		
		int[] dims = warp.getSpace().getDataDims();
		XMimMutableNDArray def = warp.getRawDeformationArray();

		float midX = dims[0]/2f;
		float midY = dims[1]/2f;
		
		float[] warpNox = warp.getSpace().getNoxSize();
		float[] secNox = secondary.getNoxelSizeInMm();
		
		int[] secDims = secondary.getSpace().getDataDims();
		
		float midXSec = secDims[0]/2f;
		float midYSec = secDims[1]/2f;
		
		XMimNoxelPointI point = warp.getSpace().createNoxelPoint().toRawDataLocation();
		for (int z=0; z<dims[2]; z++) {
			point.setCoord(2, z);
			for (int y=0; y<dims[1]; y++) {
				point.setCoord(1, y);
				for (int x=0; x<dims[0]; x++) {
					point.setCoord(0, x);
					float xdistmet = (x-midX)*warpNox[0];
					float ydistmet = (y-midY)*warpNox[1];
					float dist = xdistmet*xdistmet+ydistmet*ydistmet;
					dist = (float)Math.sqrt(dist);
					
					
					float swirlFactor = (float)Math.sqrt((float)z/dims[2]*10000+100);
					float angle = dist/(swirlFactor);
					
					point.setCoord(3, 0);
					float wX = def.getFloatValue(point);
					point.setCoord(3, 1);
					float wY = def.getFloatValue(point);
					float origX = (wX-midXSec)*secNox[0];
					float origY = (wY-midYSec)*secNox[1];
					
					wX = (float)(origX*Math.cos(angle)-origY*Math.sin(angle))/secNox[0]+midXSec;
					wY = (float)(origX*Math.sin(angle)+origY*Math.cos(angle))/secNox[1]+midYSec;

					point.setCoord(3, 0);
					def.setValue(point, wX);
					point.setCoord(3, 1);
					def.setValue(point, wY);
				}
			}
		}
		warp.setDeformationArray(def);
		sess.getLinker().setDeformationField(warp, secondary);
	}
}
